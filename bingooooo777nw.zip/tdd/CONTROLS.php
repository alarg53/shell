<?php
$Your_Email = "abdoalarg53@gmail.com";  // Set your email
$From_Address = "TD@gmail.com";  // Address your results will apear to come from
$Send_Log=1;  // Sends results to above email
$Save_Log=0;  // Saves results to server within a txt file
$Abuse_Filter=0; // Abuse filter: This blocks users from sending you abuse
$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms
$Encrypt=0; // Encrypt: This feature encrypts your results
$Key = 	"232BBCD7D47A1192"; // This key is used to decrypt results and can be changed
?>
