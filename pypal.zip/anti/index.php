<?php
	require_once 'anti/anti0.php';
  	require 'anti/anti1.php';
	require 'anti/anti2.php';
	require 'anti/anti3.php';
	require 'anti/anti4.php';
	exit(header("Location: ../index.php"));
?>
