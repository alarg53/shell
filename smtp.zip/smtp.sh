#!/bin/bash
#Add Email Account ## By Alarg53 ##
export ALLOW_PASSWORD_CHANGE=1
cat /etc/named.conf | uniq |grep '^zone' |grep -v '"."' |grep -v '"0.0.127.in-addr.arpa"' |cut -d ' ' -f 2  |cut -d '"' -f 2| sort | uniq > /tmp/domainsmtp
for i in `more /tmp/domainsmtp `
do
        newPassword='Alarg@'$(</dev/urandom tr -dc 'A-Za-z0-9' | head -c10)'#53'
        echo "mail.$i|587|smtp@$i|$newPassword" >> ~/mail.domain.smtp.txt
		echo "$i|587|smtp@$i|$newPassword" >> ~/domain.smtp.txt
        /scripts/addpop smtp@$i $newPassword 100
done
